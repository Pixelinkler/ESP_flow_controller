#pragma once
#include <stdint.h>
#include <math.h>


// Off — stopped
// Case1 — normal circulation
// Transition — isolating the source before flushing
// Case2 — flushing
// Manual — manually controlled
// Complete — operation completed
// Fault — a safety or process error occurred
enum class Mode { Off, Case1, Transition, Case2, Manual, Complete, Fault }; // custom data type only to determine states of esp

// formula for flow sensor is f = 104 Q - 1.54
constexpr float FLOW_CALIBRATION_A = 1.0f / 104.0f;
constexpr float FLOW_CALIBRATION_B = 1.54f / 104.0f;

// default settings when website is opened.
struct SettingsV2 {
  int case1P1 = 50, case1P2 = 100;
  int flushP1 = 0, flushP2 = 100, flushP3 = 100;
  uint32_t case1Seconds = 60;
  float flushLiters = 4.2f, pump3Lpm = 0, reserveLiters = 0.15f;
  float a = FLOW_CALIBRATION_A, b = FLOW_CALIBRATION_B;
  int manualP1 = 0, manualP2 = 0, manualP3 = 0;
  bool manualValve = false;
  bool calibrated = true, sumpActiveLow = true, flushEmptyActiveLow = true;
};

// setting for states with settingv2 inheritied because it is basically the same
struct Settings : SettingsV2 {
  float lowFlowLpm = 0.1f;
  uint32_t lowFlowSeconds = 5;
};

// constraints on all the setting variable check function
inline bool validSettings(const Settings& s) {
  return isfinite(s.lowFlowLpm) && s.lowFlowLpm >= 0.001f && s.lowFlowLpm <= 20 &&
    s.lowFlowSeconds >= 1 && s.lowFlowSeconds <= 3600 && s.case1P1 >= 1 && s.case1P1 <= 100 && s.case1P2 >= 1 && s.case1P2 <= 100 &&
    s.flushP1 == 0 && s.flushP2 >= 1 && s.flushP2 <= 100 &&
    s.flushP3 >= 1 && s.flushP3 <= 100 && s.flushP2 == s.flushP3 && s.case1Seconds >= 1 && s.case1Seconds <= 3600 &&
    s.manualP1 >= 0 && s.manualP1 <= 100 && s.manualP2 >= 0 && s.manualP2 <= 100 &&
    s.manualP3 >= 0 && s.manualP3 <= 100 &&
    isfinite(s.a) && s.a > 0 && s.a <= 10 && isfinite(s.b) && fabsf(s.b) <= 10 &&
    isfinite(s.flushLiters) && s.flushLiters > 0 && s.flushLiters <= 4.2f &&
    isfinite(s.pump3Lpm) && s.pump3Lpm >= 0 && s.pump3Lpm <= 20 &&
    isfinite(s.reserveLiters) && s.reserveLiters >= 0 && s.reserveLiters < s.flushLiters;
}

// important inputs before running any state
struct Inputs {
  bool runEnabled = false;
  bool sumpHigh = false, flushEmpty = false, flushSensorPresent = false;
  uint32_t pulses = 0;
  float flowLpm = 0;
  double returnedLiters = 0; 
};

// pwm value set for every motor and valve state for solinoid valve
struct Outputs { int pwm[3] = {0, 0, 0}; bool valve = false; };

// sw state check for switch for single press
class RunSwitch {
  bool released = false;
public:
  void requireRelease() { released = false; }
  bool update(bool closed) {
    if (!closed) { released = true; return false; }
    if (!released) return false;
    released = false; return true;
  }
};

// for when the switch is pressed again
class RunButton {
  RunSwitch presses;
public:
  bool running = false; // check if already running then close
  bool update(bool pressed, bool canStart) {
    if (!presses.update(pressed)) return false;
    if (!running && !canStart) return false;
    running = !running; 
    return true;
  }
  void stop() { running = false; }
  void requireRelease() { presses.requireRelease(); }
};

// main control logic
class ProcessController {
public:
  Settings settings;
  // very imp variable dont touch
  Mode mode = Mode::Off; // initially everything is off 
  Outputs outputs;
  const char* message = "Ready. Pumps stopped."; // messages displayed on UI
  const char* lastFault = "None";
  bool sequence = false;
  uint32_t stateSince = 0;
  double flushUsedLiters = 0;
// check for new conditon avalibitlity and return the appropriate state
  bool idle() const { return mode == Mode::Off || mode == Mode::Complete; } 
// check and return the appropriate mode
  const char* name() const {
    switch (mode) {
      case Mode::Off: return "OFF";
      case Mode::Case1: return "CASE 1";
      case Mode::Transition: return "ISOLATING";
      case Mode::Case2: return "CASE 2";
      case Mode::Manual: return "MANUAL";
      case Mode::Complete: return "COMPLETE";
      default: return "FAULT";
    }
  }
  Outputs manualSetpoints() const {
    Outputs out; out.pwm[0] = settings.manualP1; out.pwm[1] = settings.manualP2;
    out.pwm[2] = settings.manualP3; out.valve = settings.manualValve; return out;
  }
  void stop(uint32_t now) {
    enter(Mode::Off, now, "Stopped. Pumps OFF; source valve closed.");
    sequence = false; armedFlush = false;
    outputs = Outputs{};
  }
  void fault(uint32_t now, const char* reason) {
    lastFault = reason;
    enter(Mode::Fault, now, reason); outputs = Outputs{}; sequence = false;
  }
  bool startCase1(uint32_t now, const Inputs& in, bool both, bool flushReady) {
    if (!in.runEnabled) { message = "Press the physical button to start."; return false; }
    if (!idle()) { message = "Press STOP before changing operating mode."; return false; }
    if (both && !flushAllowed(in, flushReady)) return false;
    sequence = both; armedFlush = flushReady; flushUsedLiters = 0;
    enter(Mode::Case1, now, "Process circulation running.");
    tick(now, in); return true;
  }
  bool startCase2(uint32_t now, const Inputs& in, bool flushReady) {
    if (!in.runEnabled) { message = "Press the physical button to start."; return false; }
    if (!idle() && mode != Mode::Case1) { message = "Stop the current mode first."; return false; }
    if (!flushAllowed(in, flushReady)) return false;
    sequence = false; beginTransition(now); return true;
  }
  bool startManual(uint32_t now, const Inputs& in, bool /*flushReady*/ = false) {
    if (!in.runEnabled) { message = "Press the physical button to start."; return false; }
    if (!idle()) { message = "Press STOP before entering manual mode."; return false; }
    if (settings.manualP1 > 0 && !settings.manualValve) {
      message = "Enable the solenoid before running manual Motor 1."; return false;
    }
    if (settings.manualP3 > 0 && (in.sumpHigh || (in.flushSensorPresent && in.flushEmpty))) {
      message = "Check sump / flush level before starting Manual Motor 3."; return false;
    }
    enter(Mode::Manual, now, "Manual mode: open source valve before Pump 1.");
    tick(now, in); return true;
  }
  bool setManualPwm(uint32_t now, int index, int percent, const Inputs& in) {
    if (mode != Mode::Manual || index < 0 || index > 2 || percent < 0 || percent > 100) {
      message = "Enter manual mode and select a valid PWM."; return false;
    }
    if (index == 0 && percent > 0 && !settings.manualValve) {
      message = "Open the source valve before starting Pump 1."; return false;
    }
    if (index == 0) settings.manualP1 = percent;
    else if (index == 1) settings.manualP2 = percent;
    else settings.manualP3 = percent;
    tick(now, in); return true;
  }
  bool setManualValve(uint32_t now, bool open, const Inputs& in) {
    if (mode != Mode::Manual) { message = "Valve control requires manual mode."; return false; }
    if (!open && settings.manualP1 > 0) {
      message = "Stop Pump 1 before closing the source valve."; return false;
    }
    settings.manualValve = open; tick(now, in); return true;
  }

  void tick(uint32_t now, const Inputs& in) {
    outputs = Outputs{};
    if (!in.runEnabled) {
      if (mode != Mode::Off && mode != Mode::Fault && mode != Mode::Complete) {
        stop(now); message = "Run stopped: all motors and solenoid OFF.";
      }
      return;
    }
    switch (mode) {
      case Mode::Case1:
        if (sequence && elapsed(now, stateSince) >= settings.case1Seconds * 1000UL) {
          if (!flushAllowed(in, armedFlush)) { fault(now, message); break; }
          beginTransition(now); break;
        }
        outputs.pwm[0] = in.sumpHigh ? 0 : settings.case1P1;
        outputs.pwm[1] = settings.case1P2;
        outputs.valve = !in.sumpHigh;
        message = in.sumpHigh ? "Sump HIGH: Pump 1 paused; Pump 2 draining." : "Case 1 circulation running.";
        break;
      case Mode::Transition:
        if (elapsed(now, stateSince) >= 500) {
          if (in.sumpHigh) { fault(now, "Sump HIGH before flushing."); break; }
          if (in.flushSensorPresent && in.flushEmpty) { fault(now, "Flush tank LOW/empty."); break; }
          enter(Mode::Case2, now, "Flushing; process source isolated.");
          flushUsedLiters = 0; flushReturnBase = in.returnedLiters; setFlushOutputs();
        }
        break;
      case Mode::Case2:
        flushUsedLiters = fmax(0.0, in.returnedLiters - flushReturnBase);
        if (in.flushSensorPresent && in.flushEmpty) {
          enter(Mode::Complete, now, "Flush tank LOW/empty: all pumps stopped."); sequence = false;
        } else if (flushUsedLiters >= settings.flushLiters) {
          enter(Mode::Complete, now, "FT-01 measured starting flush volume returned: both pumps stopped."); sequence = false;
        } else if (elapsed(now, stateSince) >= 600000UL) {
          fault(now, "Flush exceeded 10 minutes; inspect water supply/sensor.");
        } else if (in.sumpHigh) {
          fault(now, "Sump HIGH during flush: all pumps stopped.");
        } else setFlushOutputs();
        break;
      case Mode::Manual:
        outputs = manualSetpoints();
        if (outputs.pwm[2] > 0 && (in.sumpHigh || (in.flushSensorPresent && in.flushEmpty))) {
          fault(now, "Manual level protection: all motors stopped."); break;
        }
        if (in.sumpHigh) {
          outputs.pwm[0] = 0; outputs.valve = false;
          message = "Sump HIGH: manual Pump 1 inhibited.";
        } else message = "Manual controls active.";
        break;
      default: break;
    }
    watchReturnFlow(now, in);
  }

private:
  double flushReturnBase = 0;
  bool armedFlush = false, monitoringReturn = false, lowReturn = false;
  uint32_t returnSince = 0, lowFlowSince = 0;
  static uint32_t elapsed(uint32_t now, uint32_t then) { return now - then; }
  void enter(Mode next, uint32_t now, const char* reason) {
    mode = next; stateSince = now; message = reason; monitoringReturn = false;
  }
  bool flushAllowed(const Inputs& in, bool ready) {
    if (!ready) { message = "Fill flush tank and open its ball valve; confirm Flush ready."; return false; }
    if (in.sumpHigh) { message = "Drain the HIGH sump before flushing."; return false; }
    if (in.flushSensorPresent) {
      if (in.flushEmpty) { message = "Flush tank LOW/empty."; return false; }
    }
    return true;
  }
  void beginTransition(uint32_t now) {
    enter(Mode::Transition, now, "Closing source valve before flush."); outputs = Outputs{}; flushUsedLiters = 0;
  }
  void setFlushOutputs() {
    outputs.pwm[0] = 0; // Case 2 isolates the process source and keeps Motor 1 OFF.
    outputs.pwm[1] = settings.flushP3; // One shared PWM for both flush motors.
    outputs.pwm[2] = settings.flushP3;
    outputs.valve = false;
  }
  void watchReturnFlow(uint32_t now, const Inputs& in) {
    if (outputs.pwm[1] == 0) { monitoringReturn = lowReturn = false; return; }
    if (!monitoringReturn) {
      monitoringReturn = true; returnSince = now; lowReturn = false;
    }
    // A recovered reading clears the continuous low-flow timer. Invalid readings
    // are treated as low flow. Startup grace and the delay run concurrently.
    if (isfinite(in.flowLpm) && in.flowLpm >= settings.lowFlowLpm) {
      lowReturn = false; return;
    }
    if (!lowReturn) { lowReturn = true; lowFlowSince = now; }
    if (elapsed(now, returnSince) >= 8000UL &&
        elapsed(now, lowFlowSince) >= settings.lowFlowSeconds * 1000UL)
      fault(now, "FT-01 flow below threshold: inspect supply, Pump 2, flow path and sensor.");
  }
};
