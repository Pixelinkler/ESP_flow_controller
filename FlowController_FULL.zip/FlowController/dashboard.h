#pragma once
#include <Arduino.h>
// bhai i will write this using AI hogya mera toh
const char DASHBOARD[] PROGMEM = R"HTML(
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lam Controller</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f3f6f8;color:#182b3a;font:16px system-ui,sans-serif}main{max-width:760px;margin:auto;padding:20px}h1{font-size:25px}h2{font-size:18px;margin-top:0}.panel{background:white;border:1px solid #d7e0e6;border-radius:10px;padding:18px;margin:14px 0}.row{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.metric strong{display:block;font-size:26px;margin:8px 0}small,p{color:#536777;line-height:1.5}label{display:block;margin:12px 0}input[type=number],select{width:100%;padding:10px;border:1px solid #bac9d3;border-radius:6px;font:inherit}button{padding:11px 16px;border:0;border-radius:6px;background:#176c60;color:white;font:inherit;cursor:pointer}.stop{background:#b72b37}button:disabled{opacity:.45;cursor:default}#message{padding:12px;background:#e9f3f0;border-radius:6px;line-height:1.5}#notice{min-height:24px;color:#a22b34}.status{line-height:1.9}summary{cursor:pointer;font-weight:600}input[type=checkbox]{width:18px;height:18px;vertical-align:middle}@media(max-width:500px){main{padding:12px}.grid{grid-template-columns:1fr}}
</style></head><body><main>
<div class="row"><h1>Lam Controller</h1><span id="connection">Connecting…</span></div>
<div id="message" role="status">Waiting for ESP32…</div>
<section class="panel"><div class="metric">Return flow<strong id="flow" style="font-size:48px">—</strong><small>L/min</small></div></section>
<section class="panel"><h2>Operating mode</h2>
<label>Choose mode<select id="choice"><option value="case1">Case 1</option><option value="case2">Case 2</option><option value="both">Case 1 → Case 2</option><option value="manual">Manual</option></select></label>
<label id="readyLabel" hidden><input type="checkbox" id="ready"> Flush tank has water and its manual valve is open</label>
<div class="row"><button id="selectMode">Select mode</button><button id="stop" class="stop">STOP / Clear fault</button></div>
<p>Select a mode, then press the physical button once to start. Release it; the process keeps running. Press it again to stop. Selecting a mode stops the current run and requires a fresh press.</p>
<div class="status">Selected: <b id="selected">—</b><br>Controller: <b id="mode">—</b><br>Physical button: <b id="switch">—</b><br>Sump: <b id="sump">—</b><br>Motor outputs: <b id="outputs">—</b><br>Solenoid command: <b id="valve">—</b></div>
</section>
<section class="panel"><div class="row" role="tablist" aria-label="Mode settings">
<button id="tabCase1" role="tab" aria-selected="true">Case 1</button><button id="tabCase2" role="tab" aria-selected="false">Case 2</button><button id="tabManual" role="tab" aria-selected="false">Manual</button></div>
<div id="case1Settings" role="tabpanel"><h2>Case 1 settings</h2><form id="case1Form"><div class="grid"><label>Motor 1 PWM (%)<input id="case1P1" type="number" min="1" max="100" step="1" required></label><label>Motor 2 PWM (%)<input id="case1P2" type="number" min="1" max="100" step="1" required></label></div><p>Motor 3 stays OFF. Motor 1 and the source solenoid pause at sump HIGH while Motor 2 drains.</p><button id="saveCase1">Save Case 1 settings</button></form></div>
<div id="case2Settings" role="tabpanel" hidden><h2>Case 2 settings</h2><form id="case2Form"><div class="grid"><label>Flush tank starting water (L)<input id="case2Volume" type="number" min="0.01" max="4.2" step="any" required></label><label>Shared Motor 2 / Motor 3 PWM (%)<input id="case2Pwm" type="number" min="1" max="100" step="1" required></label></div><label id="combinedDelay">Case 1 → Case 2 delay (seconds)<input id="sequenceSeconds" type="number" min="1" max="3600" step="1" required></label><p>Motor 1 stays OFF and the solenoid stays closed. FT-01 totalizes the returned flush water; both running motors stop when measured volume reaches the entered starting water. The delay applies only to the combined mode.</p><button id="saveCase2">Save Case 2 settings</button></form><div class="grid"><div class="metric">Measured flush returned<strong id="flushUsed">0.000</strong><small>litres</small></div><div class="metric">Estimated water remaining<strong id="flushRemaining">—</strong><small>litres</small></div><div class="metric">Estimated time remaining<strong id="flushEta">—</strong><small>seconds · at current flow</small></div></div><p>FT-01 measures the sump return, not the flush tank level. Sump inventory or other sources affect the depletion estimate. A fitted low-level float also stops flushing.</p></div>
<div id="manualSettings" role="tabpanel" hidden><h2>Manual motor and solenoid settings</h2><p id="manualPump3Help" role="status"></p><form id="motorForm"><div class="grid"><label>Motor 1 (%)<input id="p1" type="number" min="0" max="100" step="1" required></label><label>Motor 2 (%)<input id="p2" type="number" min="0" max="100" step="1" required></label><label>Motor 3 (%)<input id="p3" type="number" min="0" max="100" step="1" required></label></div><label><input id="manualValve" type="checkbox"> Solenoid ON</label><p>Set each motor PWM and the solenoid directly. Motor 1 requires the solenoid ON. Press the physical button to start and press it again to stop.</p><button id="saveMotors">Save Manual settings</button></form></div></section>
<section class="panel"><h2>Low-flow failsafe</h2>
<form id="failsafeForm"><div class="grid"><label>Minimum return flow (L/min)<input id="lowFlowLpm" type="number" min="0.001" max="20" step="any" required></label><label>Shutoff delay (seconds)<input id="lowFlowSeconds" type="number" min="1" max="3600" step="1" required></label></div>
<p>When Motor 2 is running, all motors and the solenoid turn OFF if FT-01 flow stays below the threshold for this delay. Flow recovery resets the timer. The first 8 seconds allow startup; the delay counts during this grace period. Applies to Case 1, Case 2 and Manual.</p>
<p id="failsafeStatus"></p><button id="saveFailsafe">Save failsafe settings</button><p>Stop and release the physical button before saving. Settings survive restart.</p></form></section>
<details class="panel"><summary>Sensor and solenoid checks</summary><p id="diagnostics">Waiting for readings…</p>
<p id="controllerHealth">Waiting for controller diagnostics…</p>
<p>Pulse count should increase with water flow. The solenoid command and GPIO level do not confirm physical valve movement. Processes continue after the physical button is released, subject to flow and level protections. Press again to stop. After a fault, correct its cause and select the mode again.</p>
<button id="zero">Reset flow totals</button></details>
<p id="notice" role="alert"></p>
<section class="panel"><h2>Case 1 results</h2>
<div class="grid"><div class="metric">Current return flow<strong id="case1Flow">—</strong><small>mL/s</small></div><div class="metric">Total returned to 10 L tank<strong id="case1Total">0.000</strong><small>litres · this Case 1 run</small></div><div class="metric">Case 1 elapsed time<strong id="case1Time">0.0</strong><small>seconds</small></div></div>
<p id="case1Status">Start Case 1 using the physical button to record its results.</p>
<canvas id="trend" width="680" height="260" style="width:100%;height:auto" aria-label="Case 1 flow versus time in mL/s"></canvas>
<div class="row"><button id="exportCase1">Download Case 1 CSV</button><button id="exportGraph">Download graph PNG</button></div>
<p>The ESP32 records the latest Case 1 run, including the Case 1 phase of the combined mode. The graph shows mL/s versus seconds; the main reading shows L/min for screenshots. Download results before starting another Case 1 run or restarting the ESP32.</p></section>
<section class="panel"><h2>Recorded trials</h2>
<p>Record at least five different stable flow conditions. Press the physical button once to start the selected process and its trial. Press it again to stop and finish the trial. A fault, automatic completion, dashboard STOP or mode change also ends the trial. The ESP32 records pulses and elapsed time independently of Wi-Fi, then sends the completed result. Enter the collected water volume and save each trial.</p>
<p id="trialStatus">No trial started.</p>
<div class="grid"><div class="metric">Trial pulses (N)<strong id="trialPulses">0</strong><small>This trial only</small></div><div class="metric">Trial time (t)<strong id="trialTime">0.000</strong><small>seconds</small></div><div class="metric">Trial frequency (N/t)<strong id="trialFrequency">0.000</strong><small>Hz · average over this trial</small></div></div>
<p>Trial readings are sent after the process stops. Use the completed trial count and time for Q2.2/Q2.3.</p>
<label>Collected volume (L)<input id="collectedVolume" type="number" min="0.000001" step="any"></label>
<div class="row"><button id="saveTrial" disabled>Save trial</button><button id="exportTrials">Download trials CSV</button></div>
<div style="overflow-x:auto"><table style="width:100%;text-align:left;border-spacing:10px"><thead><tr><th>Trial</th><th>Pulses N</th><th>Time (s)</th><th>Frequency (Hz)</th><th>Volume (L)</th><th>Actual flow (L/min)</th></tr></thead><tbody id="trialRecords"></tbody></table></div></section>

</main><script>
const $=id=>document.getElementById(id);
const names={none:'None',case1:'Case 1',case2:'Case 2',both:'Case 1 → Case 2',manual:'Manual'};
let state=null,online=false,busy=false,polling=false,loaded=false,lastUptime=null,lastBoot=null;
async function request(path,values){
 const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),3500);
 try{const response=await fetch(path,{method:values?'POST':'GET',body:values?new URLSearchParams(values):undefined,cache:'no-store',signal:abort.signal});
 if(!response.ok)throw Error(await response.text());return values?await response.text():await response.json();}
 finally{clearTimeout(timer);}
}
function manualPump3Status(){
 if(!state||$('choice').value!=='manual'){$('manualPump3Help').textContent='';return;}
 const d=state;
 $('manualPump3Help').textContent=d.sump?'Sump HIGH: Motor 1 is inhibited and Motor 3 cannot run.':d.flushSensor&&d.flushEmpty?'Flush level sensor reports LOW/empty: Motor 3 cannot run.':'Manual uses independent motor PWM values. It has no automatic water budget or duration limit.';
}
function controls(){
 manualPump3Status();
 const idle=state&&(state.mode==='OFF'||state.mode==='COMPLETE');
 $('selectMode').disabled=!online||busy;
 for(const id of ['saveMotors','saveCase1','saveCase2','saveFailsafe'])$(id).disabled=!online||busy||!idle||state.runEnabled||state.button;
}
async function operate(task){if(busy)return;busy=true;controls();try{$('notice').textContent=await task();}catch(e){$('notice').textContent=e.message;}finally{busy=false;controls();}}
function showTab(tab){
 for(const name of ['Case1','Case2','Manual']){
  $('tab'+name).setAttribute('aria-selected',String(name===tab));
  $(name==='Case1'?'case1Settings':name==='Case2'?'case2Settings':'manualSettings').hidden=name!==tab;
 }
 $('combinedDelay').hidden=$('choice').value!=='both';
 $('readyLabel').hidden=tab!=='Case2';
 manualPump3Status();
}
function profile(){
 if(!state)return;
 $('case1P1').value=state.case1[0];$('case1P2').value=state.case1[1];
 $('case2Pwm').value=state.case2[2];$('case2Volume').value=state.volume;$('sequenceSeconds').value=state.seconds;
 for(let i=1;i<=3;i++)$('p'+i).value=state.manual[i-1];
 $('manualValve').checked=state.manualValve;
 $('lowFlowLpm').value=state.lowFlowLpm;$('lowFlowSeconds').value=state.lowFlowSeconds;
 showTab($('choice').value==='manual'?'Manual':$('choice').value==='case1'?'Case1':'Case2');
}
$('choice').onchange=()=>showTab($('choice').value==='manual'?'Manual':$('choice').value==='case1'?'Case1':'Case2');
$('tabCase1').onclick=()=>{$('choice').value='case1';showTab('Case1');};
$('tabCase2').onclick=()=>{if($('choice').value!=='both')$('choice').value='case2';showTab('Case2');};
$('tabManual').onclick=()=>{$('choice').value='manual';showTab('Manual');};
$('ready').onchange=manualPump3Status;
$('selectMode').onclick=()=>operate(()=>request('/api/action',{action:$('choice').value,ready:$('ready').checked?'1':'0'}));
$('stop').onclick=()=>operate(()=>request('/api/action',{action:'stop'}));
$('zero').onclick=()=>operate(()=>request('/api/action',{action:'zero'}));
$('case1Form').onsubmit=e=>{e.preventDefault();operate(async()=>{
 const p1=$('case1P1').value,p2=$('case1P2').value;
 await request('/api/pwm',{profile:'case1',pump:1,duty:p1});await request('/api/pwm',{profile:'case1',pump:2,duty:p2});
 return 'Case 1 settings saved. Select the mode, then press the physical button.';
});};
$('case2Form').onsubmit=e=>{e.preventDefault();operate(()=>request('/api/case2',{pwm:$('case2Pwm').value,volume:$('case2Volume').value,seconds:$('sequenceSeconds').value}));};
$('motorForm').onsubmit=e=>{e.preventDefault();operate(()=>request('/api/manual',{p1:$('p1').value,p2:$('p2').value,p3:$('p3').value,valve:$('manualValve').checked?'1':'0'}));};
$('failsafeForm').onsubmit=e=>{e.preventDefault();operate(()=>request('/api/failsafe',{lpm:$('lowFlowLpm').value,seconds:$('lowFlowSeconds').value}));};
async function poll(){
 if(polling)return;polling=true;
 try{
 const data=await request('/api/status');const old=state;state=data;online=true;$('connection').textContent='Connected';
 if((lastBoot!==null&&data.bootCount!==undefined&&data.bootCount!==lastBoot)||(lastUptime!==null&&data.ms<lastUptime)){
  loaded=false;$('notice').textContent='ESP32 restarted: '+(data.resetReason||'check Serial Monitor')+'. Select a mode again, then release and press the switch.';
 }
 lastUptime=data.ms;lastBoot=data.bootCount??null;
 $('flow').textContent=data.lpm.toFixed(3);
 $('failsafeStatus').textContent='Saved: below '+data.lowFlowLpm+' L/min for '+data.lowFlowSeconds+' seconds.';
 if(old&&old.lowFlowLpm!==data.lowFlowLpm)$('lowFlowLpm').value=data.lowFlowLpm;
 if(old&&old.lowFlowSeconds!==data.lowFlowSeconds)$('lowFlowSeconds').value=data.lowFlowSeconds;
 $('flushUsed').textContent=data.flushUsed.toFixed(3);$('flushRemaining').textContent=data.flushRemaining.toFixed(3);$('flushEta').textContent=data.flushEtaSeconds>=0?data.flushEtaSeconds.toFixed(1):'—';
 $('message').textContent=data.message;$('selected').textContent=(names[data.selected]||data.selected)+(data.armed?' · ready for switch':' · select to arm');
 $('mode').textContent=data.mode;$('switch').textContent=(data.button?'PRESSED':'RELEASED')+' · process '+(data.runEnabled?'RUNNING':'STOPPED');$('sump').textContent=data.sump?'HIGH':'Below high level';
 $('outputs').textContent=data.actual.map((p,i)=>'M'+(i+1)+' '+p+'%').join(' · ');$('valve').textContent=data.valve?'ON':'OFF';
 $('diagnostics').textContent='Flow GPIO14: '+data.flowRaw+' · Last sample: '+data.intervalPulses+' pulses in '+(data.sampleMs/1000).toFixed(3)+' s · Solenoid GPIO27: '+data.valvePin+' · Button GPIO34: '+data.buttonRaw+' · Flush sensor: '+(data.flushSensor?'Fitted':'Not fitted');
 $('controllerHealth').textContent='Uptime: '+Math.floor(data.ms/1000)+' s · Boot: '+data.bootCount+' · Reset reason: '+data.resetReason+' · Last fault: '+(data.lastFault||'None')+' · Free memory: '+data.freeHeap+' bytes';
 if(!loaded){profile();loaded=true;}
 if(old&&old.case2[2]!==data.case2[2])$('case2Pwm').value=data.case2[2];
 if(old&&old.volume!==data.volume)$('case2Volume').value=data.volume;
 if(old&&old.seconds!==data.seconds)$('sequenceSeconds').value=data.seconds;
 await receiveTrials(data);
 await receiveCase1(data);
 controls();
 }catch(e){online=false;$('connection').textContent='Disconnected';$('message').textContent='No reply from ESP32. Last readings are stale. Check the Lam-Stage2 Wi-Fi connection; after reconnection check uptime and reset reason.';controls();}
 finally{polling=false;}
}
const trials=[],case1Rows=[];
let trialEnd=null,lastTrialFetch=null,case1Key=null,case1After=0,case1FetchedCount=-1;
const pendingTrials=[],receivedTrialIds=new Set();
function download(name,rows){
 if(!rows.length){$('notice').textContent='No records to download.';return;}
 const keys=Object.keys(rows[0]),quote=v=>'"'+String(v??'').replaceAll('"','""')+'"';
 const csv=[keys.map(quote).join(','),...rows.map(row=>keys.map(key=>quote(row[key])).join(','))].join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function plot(id,points,xLabel,yLabel,target){
 const canvas=$(id),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height,left=64,right=w-20,top=20,bottom=h-42;
 ctx.clearRect(0,0,w,h);ctx.font='12px system-ui';ctx.fillStyle='#536777';
 ctx.fillText(yLabel,left,14);ctx.fillText(xLabel,w/2-40,h-5);
 if(!points.length)return;
 const xmin=Math.min(...points.map(p=>p[0])),xmax=Math.max(xmin+1,...points.map(p=>p[0]));
 const ymax=Math.max(1,target||0,...points.map(p=>p[1]))*1.15;
 const x=v=>left+(v-xmin)/(xmax-xmin)*(right-left),y=v=>bottom-v/ymax*(bottom-top);
 ctx.strokeStyle='#bac9d3';ctx.beginPath();ctx.moveTo(left,top);ctx.lineTo(left,bottom);ctx.lineTo(right,bottom);ctx.stroke();
 ctx.fillText('0',20,bottom);ctx.fillText(ymax.toFixed(1),15,top+5);ctx.fillText(xmin.toFixed(1),left,bottom+18);ctx.fillText(xmax.toFixed(1),right-35,bottom+18);
 if(target){ctx.setLineDash([5,5]);ctx.strokeStyle='#b72b37';ctx.beginPath();ctx.moveTo(left,y(target));ctx.lineTo(right,y(target));ctx.stroke();ctx.setLineDash([]);ctx.fillText('Target '+target,right-85,y(target)-4);}
 ctx.strokeStyle='#176c60';ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(x(p[0]),y(p[1])):ctx.moveTo(x(p[0]),y(p[1])));ctx.stroke();
 ctx.fillStyle='#176c60';points.forEach(p=>{ctx.beginPath();ctx.arc(x(p[0]),y(p[1]),2,0,Math.PI*2);ctx.fill();});
}
async function receiveCase1(data){
 $('case1Flow').textContent=data.mode==='CASE 1'?(data.lpm*1000/60).toFixed(3):'—';
 $('case1Total').textContent=data.case1Liters.toFixed(3);$('case1Time').textContent=(data.case1ElapsedMs/1000).toFixed(1);
 if(!data.case1RunId){case1Key=null;case1Rows.length=0;case1After=0;case1FetchedCount=-1;plot('trend',[],'Elapsed time (s)','Return flow (mL/s)',50);$('case1Status').textContent='Start Case 1 using the physical button to record its results.';return;}
 const key=data.bootCount+':'+data.case1RunId;
 if(key!==case1Key){case1Key=key;case1Rows.length=0;case1After=0;case1FetchedCount=-1;}
 if(case1After<data.case1SampleCount||case1FetchedCount!==data.case1SampleCount){
  const result=await request('/api/case1?run='+data.case1RunId+'&after='+case1After);
  const resultKey=result.bootCount+':'+result.runId;
  if(resultKey!==case1Key){case1Key=resultKey;case1Rows.length=0;case1After=0;}
  for(const sample of result.samples){if(sample.seq<=case1After)continue;case1After=sample.seq;case1Rows.push({elapsed_s:sample.elapsedMs/1000,flow_ml_s:sample.lpm*1000/60,flow_lpm:sample.lpm,total_returned_l:sample.liters});}
  if(case1Rows.length>1200)case1Rows.splice(0,case1Rows.length-1200);
  case1FetchedCount=result.totalSamples;
  plot('trend',case1Rows.map(row=>[row.elapsed_s,row.flow_ml_s]),'Elapsed time (s)','Return flow (mL/s)',50);
  $('case1Status').textContent='Case 1 run '+result.runId+' · '+(result.active?'Recording on ESP32':'Completed')+' · '+case1Rows.length+' samples retrieved'+(result.discarded?' · '+result.discarded+' older samples exceeded 20-minute storage':'')+'.';
 }else $('case1Status').textContent='Case 1 run '+data.case1RunId+' · '+(data.case1Recording?'Recording on ESP32':'Completed')+' · '+case1Rows.length+' samples retrieved.';
}
$('exportCase1').onclick=()=>download('case1-flow.csv',case1Rows);
$('exportGraph').onclick=()=>{
 if(!case1Rows.length){$('notice').textContent='No Case 1 graph recorded yet.';return;}
 $('trend').toBlob(blob=>{const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='case1-flow-ml-per-second.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
};
function renderTrial(reading){
 $('trialPulses').textContent=reading.pulses;$('trialTime').textContent=reading.seconds.toFixed(3);
 $('trialFrequency').textContent=reading.hz.toFixed(3);
}
function showPendingTrial(recording=false){
 trialEnd=pendingTrials[0]||null;
 $('saveTrial').disabled=!trialEnd;
 if(trialEnd){
  renderTrial(trialEnd);
  $('trialStatus').textContent='Hardware trial '+trialEnd.trialId+' (boot '+trialEnd.bootCount+'): enter collected litres and save. '+pendingTrials.length+' unsaved trial(s).'+(recording?' Another process trial is recording on ESP32.':'');
 }else{
  renderTrial({pulses:0,seconds:0,hz:0});
  $('trialStatus').textContent=recording?'Process running: recording on ESP32. Press the physical button again to stop.':'Select a mode and press the physical button once to start; press again to stop and get the result.';
 }
}
async function receiveTrials(data){
 const key=data.bootCount+':'+data.completedTrials;
 if(key!==lastTrialFetch){
  const result=await request('/api/measurement');
  for(const record of result.trials){
   const id=result.bootCount+':'+record.trialId;
   if(receivedTrialIds.has(id))continue;
   receivedTrialIds.add(id);pendingTrials.push({...record,bootCount:result.bootCount,seconds:record.milliseconds/1000});
  }
  lastTrialFetch=key;
  if(result.discarded)$('notice').textContent=result.discarded+' older ESP32 trial(s) exceeded its 32-trial storage limit.';
 }
 showPendingTrial(data.trialRecording);
}
$('saveTrial').onclick=()=>{
 const volume=Number($('collectedVolume').value);
 if(!trialEnd||trialEnd.seconds<=0||!Number.isFinite(volume)||volume<=0){$('notice').textContent='Stop the process to complete a trial and enter a positive collected volume.';return;}
 trials.push({trial:trials.length+1,hardware_trial:trialEnd.trialId,boot:trialEnd.bootCount,pulses:trialEnd.pulses,time_s:trialEnd.seconds,frequency_hz:trialEnd.pulses/trialEnd.seconds,collected_l:volume,actual_lpm:volume*60/trialEnd.seconds});
 pendingTrials.shift();$('collectedVolume').value='';showPendingTrial(state?.trialRecording);
 $('trialRecords').innerHTML=trials.map(t=>'<tr><td>'+t.trial+'</td><td>'+t.pulses+'</td><td>'+t.time_s.toFixed(3)+'</td><td>'+t.frequency_hz.toFixed(3)+'</td><td>'+t.collected_l+'</td><td>'+t.actual_lpm.toFixed(3)+'</td></tr>').join('');
};
$('exportTrials').onclick=()=>download('calibration-trials.csv',trials);
setInterval(poll,500);poll();
</script></body></html>
)HTML";
