#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <esp_arduino_version.h>
#include <esp_system.h>
#include "BoardPins.h"
#include "ControlLogic.h"
#include "FlowReading.h"
#include "dashboard.h"

WebServer server(80);
Preferences preferences;
ProcessController controller;
SemaphoreHandle_t controlMutex;
volatile uint32_t pulseCounter = 0;
portMUX_TYPE pulseMux = portMUX_INITIALIZER_UNLOCKED;
bool pwmReady = true;
uint32_t sampleStarted = 0, sampleBase = 0;
PulseTrial measurementTrial;
const uint32_t TRIAL_CAPACITY = 32;
PulseTrial recordedTrials[TRIAL_CAPACITY];
uint32_t recordedTrialCount = 0;
uint64_t totalPulses = 0;
uint64_t pulseElapsedMs = 0;
uint32_t sampleMs = 0;
double totalLiters = 0, sensorLiters = 0;
const uint32_t CASE1_CAPACITY = 1200; // Twenty minutes at one sample per second.
Case1Sample case1Samples[CASE1_CAPACITY];
uint32_t case1RunId = 0, case1SampleCount = 0, case1ElapsedMs = 0;
double case1Liters = 0;
bool case1Recording = false;
float frequencyHz = 0, flowLpm = 0;
uint32_t bootCount = 0;
esp_reset_reason_t bootResetReason;

const char* resetReasonName(esp_reset_reason_t reason) {
  switch (reason) {
    case ESP_RST_POWERON: return "Power-on / reset pin";
    case ESP_RST_SW: return "Software restart";
    case ESP_RST_PANIC: return "Crash / exception";
    case ESP_RST_INT_WDT: return "Interrupt watchdog";
    case ESP_RST_TASK_WDT: return "Task watchdog";
    case ESP_RST_WDT: return "Other watchdog";
    case ESP_RST_DEEPSLEEP: return "Deep sleep";
    case ESP_RST_BROWNOUT: return "Brownout / supply voltage drop";
    case ESP_RST_SDIO: return "SDIO reset";
    default: return "Unknown / external reset";
  }
}

struct DebouncedInput {
  int pin; uint32_t debounceMs;
  int stable = HIGH, candidate = HIGH;
  uint32_t changedAt = 0;
  DebouncedInput(int gpio, uint32_t debounce) : pin(gpio), debounceMs(debounce) {}
  void begin() {
    if (pin < 0) return;
    pinMode(pin, pin >= 34 ? INPUT : INPUT_PULLUP);
    stable = candidate = digitalRead(pin); changedAt = millis();
  }
  void update(uint32_t now) {
    if (pin < 0) return;
    int value = digitalRead(pin);
    if (value != candidate) { candidate = value; changedAt = now; }
    if (uint32_t(now - changedAt) >= debounceMs) stable = candidate;
  }
  bool active(bool low) const { return pin >= 0 && stable == (low ? LOW : HIGH); }
};
DebouncedInput sump{SUMP_FLOAT_PIN, 100}, flushFloat{FLUSH_FLOAT_PIN, 30}, button{BUTTON_PIN, 50};
RunButton runButton;
enum class Selection { None, Case1, Case2, Both, Manual };
Selection selectedMode = Selection::None;
bool selectionArmed = false, selectedFlushReady = false;
uint32_t intervalPulses = 0;

bool switchClosed() {
  // Physical button state is separate 
  return button.active(RUN_SWITCH_ACTIVE_LOW) &&
    digitalRead(BUTTON_PIN) == (RUN_SWITCH_ACTIVE_LOW ? LOW : HIGH);
}
const char* selectionName() {
  switch (selectedMode) {
    case Selection::Case1: return "case1";
    case Selection::Case2: return "case2";
    case Selection::Both: return "both";
    case Selection::Manual: return "manual";
    default: return "none";
  }
}

void IRAM_ATTR flowInterrupt() {
  portENTER_CRITICAL_ISR(&pulseMux); ++pulseCounter; portEXIT_CRITICAL_ISR(&pulseMux);
}
uint32_t readPulses() {
  portENTER_CRITICAL(&pulseMux); uint32_t result = pulseCounter; portEXIT_CRITICAL(&pulseMux); return result;
}
PulseSnapshot pulseSnapshot() {
  portENTER_CRITICAL(&pulseMux);
  const PulseSnapshot snapshot = {millis(), pulseCounter};
  portEXIT_CRITICAL(&pulseMux);
  return snapshot;
}
void finishMeasurement() {
  if (!measurementTrial.active) return;
  finishCase1Recording(millis());
  measurementTrial.stop(pulseSnapshot());
  recordedTrials[recordedTrialCount % TRIAL_CAPACITY] = measurementTrial;
  ++recordedTrialCount;
}
void stopRun(uint32_t now) {
  runButton.stop(); controller.stop(now); finishMeasurement();
}
Inputs inputs() {
  Inputs in;
  in.runEnabled = runButton.running;
  in.sumpHigh = sump.active(controller.settings.sumpActiveLow);
  in.flushEmpty = flushFloat.active(controller.settings.flushEmptyActiveLow);
  in.flushSensorPresent = FLUSH_FLOAT_PIN >= 0;
  in.pulses = readPulses();
  in.returnedLiters = sensorLiters;
  in.flowLpm = flowLpm;
  return in;
}
void writePwm(int index, int percent) {
  uint32_t duty = uint32_t(percent) * ((1UL << PWM_RESOLUTION) - 1) / 100;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(PINS[index].pwm, duty);
#else
  ledcWrite(index, duty);
#endif
}
void applyOutputs() {
  const Outputs& out = controller.outputs;
  const bool allowed = runButton.running && pwmReady;
  const bool valveOn = allowed && out.valve;
  if (valveOn) digitalWrite(VALVE_PIN, VALVE_ACTIVE_HIGH ? HIGH : LOW);
  for (int i = 0; i < 3; ++i) {
    int duty = allowed ? out.pwm[i] : 0;
    if (duty == 0) {
      writePwm(i, 0); digitalWrite(PINS[i].enableL, LOW); digitalWrite(PINS[i].enableR, LOW);
    } else {
      if (PINS[i].reverse >= 0) digitalWrite(PINS[i].reverse, LOW);
      digitalWrite(PINS[i].enableL, HIGH); digitalWrite(PINS[i].enableR, HIGH); writePwm(i, duty);
    }
  }
  if (!valveOn) digitalWrite(VALVE_PIN, VALVE_ACTIVE_HIGH ? LOW : HIGH);
}
void sampleFlow(uint32_t now, bool force = false) {
  uint32_t dt = now - sampleStarted;
  if (dt == 0 || (!force && dt < 1000)) return;
  uint32_t current = readPulses(), pulses = current - sampleBase;
  intervalPulses = pulses;
  sampleMs = dt;
  pulseElapsedMs += dt;
  const FlowReading reading = calculateFlow(pulses, dt, controller.settings.a, controller.settings.b);
  frequencyHz = reading.hz; flowLpm = reading.lpm;
  totalLiters += reading.liters; sensorLiters += reading.liters;
  if (case1Recording) {
    case1ElapsedMs += dt; case1Liters += reading.liters;
    case1Samples[case1SampleCount % CASE1_CAPACITY] = {case1ElapsedMs, reading.lpm, case1Liters};
    ++case1SampleCount;
  }
  totalPulses += pulses;
  sampleStarted = now; sampleBase = current;
}
void resetTotals(uint32_t now) {
  if (case1Recording) sampleFlow(now, true);
  sampleStarted = now; sampleBase = readPulses(); totalPulses = 0; totalLiters = 0;
  frequencyHz = flowLpm = 0;
  intervalPulses = 0;
  pulseElapsedMs = 0; sampleMs = 0;
}
void beginCase1Recording(uint32_t now) {
  sampleFlow(now, true);
  ++case1RunId; case1SampleCount = 0; case1ElapsedMs = 0; case1Liters = 0;
  case1Recording = true;
}
void finishCase1Recording(uint32_t now) {
  if (!case1Recording) return;
  sampleFlow(now, true); case1Recording = false;
}
void loadSettings() {
  preferences.begin("lam-flow", false);
  Settings s;
  if (preferences.getUInt("version", 0) == 3 && preferences.getBytesLength("settings") == sizeof(s))
    preferences.getBytes("settings", &s, sizeof(s));
  else if (preferences.getUInt("version", 0) == 2 && preferences.getBytesLength("settings") == sizeof(SettingsV2)) {
    preferences.getBytes("settings", static_cast<SettingsV2*>(&s), sizeof(SettingsV2));
  }
  else if (preferences.getUInt("version", 0) == 1) {
    // Preserve existing measured calibration and profiles while migrating the old layout.
    struct LegacySettings {
      int case1P1, case1P2, flushP1, flushP2, flushP3;
      uint32_t case1Seconds;
      float flushLiters, pump3Lpm, reserveLiters, a, b;
      bool calibrated, sumpActiveLow, flushEmptyActiveLow;
    } old;
    if (preferences.getBytesLength("settings") == sizeof(old)) {
      preferences.getBytes("settings", &old, sizeof(old));
      s.case1P1 = old.case1P1; s.case1P2 = old.case1P2;
      s.flushP1 = old.flushP1; s.flushP2 = old.flushP2; s.flushP3 = old.flushP3;
      s.case1Seconds = old.case1Seconds; s.flushLiters = old.flushLiters;
      s.pump3Lpm = old.pump3Lpm; s.reserveLiters = old.reserveLiters;
      if (old.calibrated) { s.a = old.a; s.b = old.b; s.calibrated = true; }
      s.sumpActiveLow = old.sumpActiveLow; s.flushEmptyActiveLow = old.flushEmptyActiveLow;
    }
  }
  s.flushP2 = s.flushP3; // Case 2 uses one shared Motor 2/3 PWM.
  s.flushP1 = 0; //  Case 2 profiles without changing other settings.
  controller.settings = validSettings(s) ? s : Settings{};

  controller.settings.a = FLOW_CALIBRATION_A;
  controller.settings.b = FLOW_CALIBRATION_B;
  controller.settings.calibrated = true;
}
void saveSettings() {
  preferences.putBytes("settings", &controller.settings, sizeof(Settings));
  preferences.putUInt("version", 3);
}

// Dedicated task keeps level/flow protection working during slow HTTP requests.
// Shared state is guarded; network I/O is always outside the mutex.
void controlTask(void*) {
  TickType_t wake = xTaskGetTickCount();
  for (;;) {
    xSemaphoreTake(controlMutex, portMAX_DELAY);
    uint32_t now = millis();
    sump.update(now); flushFloat.update(now); button.update(now);
    bool pressed = button.active(RUN_SWITCH_ACTIVE_LOW);
    const bool canStart = switchClosed() && selectionArmed && controller.idle() && pwmReady;
    if (runButton.update(pressed, canStart)) {
      if (!runButton.running) {
        controller.stop(now); finishMeasurement();
        controller.message = "Physical button pressed again: process stopped.";
      } else {
        const PulseSnapshot started = pulseSnapshot();
        bool ok = false;
        switch (selectedMode) {
          case Selection::Case1: ok = controller.startCase1(now, inputs(), false, false); break;
          case Selection::Case2: ok = controller.startCase2(now, inputs(), selectedFlushReady); break;
          case Selection::Both: ok = controller.startCase1(now, inputs(), true, selectedFlushReady); break;
          case Selection::Manual: ok = controller.startManual(now, inputs(), selectedFlushReady); break;
          default: break;
        }
        if (ok) {
          measurementTrial.start(started);
          if (controller.mode == Mode::Case1) beginCase1Recording(now);
        }
        else { runButton.stop(); selectionArmed = false; }
      }
    }
    now = millis(); // A stop can force a newer sample; never reuse an older timestamp.
    sampleFlow(now, (controller.mode == Mode::Transition && uint32_t(now - controller.stateSince) >= 500) ||
                    (controller.mode == Mode::Case2 && uint32_t(now - sampleStarted) >= 100));
    controller.tick(now, inputs());
    if (case1Recording && controller.mode != Mode::Case1) finishCase1Recording(now);
    if (controller.mode == Mode::Fault || controller.mode == Mode::Complete) {
      runButton.stop(); finishMeasurement(); selectionArmed = false;
    }
    applyOutputs();
    xSemaphoreGive(controlMutex);
    vTaskDelayUntil(&wake, pdMS_TO_TICKS(10));
  }
}
bool numberArgument(const char* key, float& value) {
  if (!server.hasArg(key)) return false;
  String text = server.arg(key); char* end;
  value = strtof(text.c_str(), &end);
  return text.length() > 0 && end != text.c_str() && *end == '\0' && isfinite(value);
}
void reply(bool ok, const String& text) { server.send(ok ? 200 : 409, "text/plain", text); }

void handleAction() {
  String action = server.arg("action"); bool ready = server.arg("ready") == "1", ok = true;
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  uint32_t now = millis();
  if (action == "stop") { stopRun(now); selectionArmed = false; }
  else if (action == "zero") { resetTotals(now); controller.message = "Flow totals reset."; }
  else if (action == "heartbeat") { /* Compatibility with an older cached dashboard. */ }
  else if (!pwmReady) { ok = false; controller.message = "PWM initialization failed."; }
  else if (action == "case1" || action == "case2" || action == "both" || action == "manual") {
    stopRun(now);
    selectedMode = action == "case1" ? Selection::Case1 : action == "case2" ? Selection::Case2 :
      action == "both" ? Selection::Both : Selection::Manual;
    selectedFlushReady = ready; selectionArmed = true;
    // Consume any already-held switch. Selection requires a fresh physical press.
    runButton.requireRelease();
    controller.message = "Mode selected. Press the physical button once to start.";
  }
  else { ok = false; controller.message = "Unknown action."; }
  applyOutputs(); String text = controller.message;
  xSemaphoreGive(controlMutex); reply(ok, text);
}
void handlePwm() {
  float p, d;
  if (!numberArgument("pump", p) || !numberArgument("duty", d) ||
      p != floorf(p) || d != floorf(d) || p < 1 || p > 3 || d < 0 || d > 100) {
    reply(false, "Invalid pump or PWM value."); return;
  }
  int index = int(p) - 1, duty = int(d);
  String profile = server.arg("profile"), text = "PWM updated."; bool ok = true;
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  Settings& s = controller.settings;
  if (profile == "manual") {
    ok = controller.setManualPwm(millis(), index, duty, inputs());
    if (!ok) text = controller.message;
  } else if (profile == "case1") {
    if (index > 1 || duty < 1 || (!controller.idle() && controller.mode != Mode::Case1)) {
      ok = false; text = "Case 1 requires Pump 1/2, 1-100%, and OFF or CASE 1.";
    } else { if (index == 0) s.case1P1 = duty; else s.case1P2 = duty; }
  } else if (profile == "case2") {
    if ((index == 0 ? duty != 0 : duty < 1) || (!controller.idle() && controller.mode != Mode::Case2)) {
      ok = false; text = "Case 2 Motor 1 must stay OFF; Motors 2/3 require 1-100%, and OFF or CASE 2.";
    } else if (index != 0 && duty != s.flushP3 && FLUSH_FLOAT_PIN < 0 && !controller.idle()) {
      ok = false; text = "Stop first: changing Pump 3 invalidates timed flushing.";
    } else {
      if (index == 0) s.flushP1 = duty;
      else {
        if (duty != s.flushP3 && FLUSH_FLOAT_PIN < 0) {
          s.pump3Lpm = 0; text = "PWM updated. Measure Pump 3 flow again before flushing.";
        }
        s.flushP2 = s.flushP3 = duty;
      }
    }
  } else { ok = false; text = "Unknown PWM profile."; }
  if (ok) { if (controller.idle()) saveSettings(); controller.tick(millis(), inputs()); applyOutputs(); }
  xSemaphoreGive(controlMutex); reply(ok, text);
}
void handleValve() {
  bool open = server.arg("open") == "1";
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  bool ok = controller.setManualValve(millis(), open, inputs());
  String text = ok ? (open ? "Source valve open." : "Source valve closed.") : controller.message;
  applyOutputs(); xSemaphoreGive(controlMutex); reply(ok, text);
}
void handleManualConfig() {
  float p1, p2, p3;
  if (!numberArgument("p1", p1) || !numberArgument("p2", p2) || !numberArgument("p3", p3) ||
      p1 != floorf(p1) || p2 != floorf(p2) || p3 != floorf(p3) ||
      p1 < 0 || p1 > 100 || p2 < 0 || p2 > 100 || p3 < 0 || p3 > 100) {
    reply(false, "Motor PWM must be a whole number from 0 to 100."); return;
  }
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  bool ok = controller.idle() && !runButton.running && !switchClosed();
  if (ok) {
    Settings& s = controller.settings;
    s.manualP1 = int(p1); s.manualP2 = int(p2); s.manualP3 = int(p3);
    s.manualValve = server.arg("valve") == "1";
    selectionArmed = false; saveSettings();
  }
  xSemaphoreGive(controlMutex);
  reply(ok, ok ? "Manual settings saved. Select Manual, then press the physical button." : "Release the switch and stop before configuring.");
}
void handleCase2Config() {
  float pwm, volume, seconds;
  if (!numberArgument("pwm", pwm) || !numberArgument("volume", volume) || !numberArgument("seconds", seconds) ||
      pwm < 1 || pwm > 100 || pwm != floorf(pwm) || volume <= 0 || volume > 4.2 ||
      seconds < 1 || seconds > 3600 || seconds != floorf(seconds)) {
    reply(false, "Enter shared PWM 1-100%, starting water >0 to 4.2 L and delay 1-3600 s."); return;
  }
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  const bool ok = controller.idle() && !runButton.running && !switchClosed();
  if (ok) {
    Settings& s = controller.settings;
    if (s.flushP3 != int(pwm) && FLUSH_FLOAT_PIN < 0) s.pump3Lpm = 0;
    s.flushP1 = 0; s.flushP2 = s.flushP3 = int(pwm);
    s.flushLiters = volume; s.case1Seconds = uint32_t(seconds);
    // Manual's reserve must remain below the actual starting water.
    if (s.reserveLiters >= s.flushLiters) s.reserveLiters = s.flushLiters * 0.1f;
    selectionArmed = false; saveSettings();
  }
  xSemaphoreGive(controlMutex);
  reply(ok, ok ? "Case 2 settings saved. Motors 2/3 share PWM; FT-01 measured volume controls shutdown. Select the mode, then press the button." : "Stop and release the physical button before saving.");
}
void handleFailsafeConfig() {
  float threshold, seconds;
  if (!numberArgument("lpm", threshold) || !numberArgument("seconds", seconds) ||
      threshold < 0.001f || threshold > 20 || seconds < 1 || seconds > 3600 || seconds != floorf(seconds)) {
    reply(false, "Enter a threshold from 0.001 to 20 L/min and a whole delay from 1 to 3600 seconds."); return;
  }
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  const bool ok = controller.idle() && !runButton.running && !switchClosed();
  if (ok) {
    controller.settings.lowFlowLpm = threshold;
    controller.settings.lowFlowSeconds = uint32_t(seconds);
    selectionArmed = false; saveSettings();
  }
  xSemaphoreGive(controlMutex);
  reply(ok, ok ? "Low-flow failsafe saved. Select the mode, then press the physical button." : "Stop and release the physical button before saving.");
}
void handleConfig() {
  float a, b, seconds, volume, rate, reserve;
  if (!numberArgument("a", a) || !numberArgument("b", b) || !numberArgument("seconds", seconds) ||
      !numberArgument("volume", volume) || !numberArgument("rate", rate) || !numberArgument("reserve", reserve) ||
      seconds < 1 || seconds > 3600 || seconds != floorf(seconds)) {
    reply(false, "Invalid configuration."); return;
  }
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  Settings next = controller.settings;
  next.a = FLOW_CALIBRATION_A; next.b = FLOW_CALIBRATION_B; next.case1Seconds = uint32_t(seconds);
  next.flushLiters = volume; next.pump3Lpm = rate; next.reserveLiters = reserve;
  next.calibrated = true;
  next.sumpActiveLow = server.arg("sumpLow") == "1";
  next.flushEmptyActiveLow = server.arg("flushLow") == "1";
  bool ok = controller.idle() && !runButton.running && !switchClosed() && validSettings(next);
  if (ok) { sampleFlow(millis(), true); controller.settings = next; saveSettings(); }
  xSemaphoreGive(controlMutex);
  reply(ok, ok ? "Settings saved." : "Stop first; verify calibration, volumes and duration.");
}
void handleStatus() {
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  const Settings& s = controller.settings;
  Inputs in = inputs(); Outputs manual = controller.manualSetpoints();
  const PulseSnapshot snapshot = pulseSnapshot();
  const bool outputsAllowed = in.runEnabled && pwmReady;
  String json; json.reserve(1600);
  // koi baat nahi sab theek hojayega
  json = "{\"mode\":\""; json += controller.name();
  json += "\",\"message\":\""; json += controller.message;
  json += "\",\"ms\":"; json += String(snapshot.ms);
  json += ",\"bootCount\":"; json += String(bootCount);
  json += ",\"trialRecording\":"; json += measurementTrial.active ? "true" : "false";
  json += ",\"completedTrials\":"; json += String(recordedTrialCount);
  json += ",\"case1RunId\":"; json += String(case1RunId);
  json += ",\"case1SampleCount\":"; json += String(case1SampleCount);
  json += ",\"case1Recording\":"; json += case1Recording ? "true" : "false";
  json += ",\"case1ElapsedMs\":"; json += String(case1ElapsedMs);
  json += ",\"case1Liters\":"; json += String(case1Liters, 6);
  json += ",\"resetReason\":\""; json += resetReasonName(bootResetReason); json += '"';
  json += ",\"lastFault\":\""; json += controller.lastFault; json += '"';
  json += ",\"freeHeap\":"; json += String(ESP.getFreeHeap());
  json += ",\"elapsed\":"; json += String(uint32_t(millis() - controller.stateSince) / 1000);
  json += ",\"lpm\":"; json += String(flowLpm, 4);
  json += ",\"mls\":"; json += String(flowLpm * 1000 / 60, 3);
  json += ",\"hz\":"; json += String(frequencyHz, 3);
  json += ",\"liters\":"; json += String(totalLiters, 5);
  char pulses[24]; snprintf(pulses, sizeof(pulses), "%llu", (unsigned long long)totalPulses);
  json += ",\"pulses\":"; json += pulses;
  char elapsedMs[24]; snprintf(elapsedMs, sizeof(elapsedMs), "%llu", (unsigned long long)pulseElapsedMs);
  json += ",\"pulseElapsedMs\":"; json += elapsedMs;
  json += ",\"sampleMs\":"; json += String(sampleMs);
  json += ",\"sump\":"; json += in.sumpHigh ? "true" : "false";
  json += ",\"sumpRaw\":"; json += String(sump.stable);
  json += ",\"button\":"; json += button.active(RUN_SWITCH_ACTIVE_LOW) ? "true" : "false";
  json += ",\"buttonRaw\":"; json += String(button.stable);
  json += ",\"runEnabled\":"; json += in.runEnabled ? "true" : "false";
  json += ",\"selected\":\""; json += selectionName(); json += '"';
  json += ",\"armed\":"; json += selectionArmed ? "true" : "false";
  json += ",\"intervalPulses\":"; json += String(intervalPulses);
  json += ",\"flowRaw\":"; json += String(digitalRead(FLOW_PIN));
  json += ",\"valvePin\":"; json += String(digitalRead(VALVE_PIN));
  json += ",\"manualValve\":"; json += s.manualValve ? "true" : "false";
  json += ",\"flushSensor\":"; json += in.flushSensorPresent ? "true" : "false";
  json += ",\"flushEmpty\":"; json += in.flushEmpty ? "true" : "false";
  json += ",\"valve\":"; json += outputsAllowed && controller.outputs.valve ? "true" : "false";
  json += ",\"sequence\":"; json += controller.sequence ? "true" : "false";
  json += ",\"flushUsed\":"; json += String(controller.flushUsedLiters, 6);
  const double remaining = fmax(0.0, s.flushLiters - controller.flushUsedLiters);
  json += ",\"flushRemaining\":"; json += String(remaining, 6);
  json += ",\"flushEtaSeconds\":"; json += String(flowLpm > 0 && controller.mode == Mode::Case2 ? remaining * 60 / flowLpm : -1, 3);
  json += ",\"actual\":[";
  for (int i = 0; i < 3; ++i) { if (i) json += ','; json += String(outputsAllowed ? controller.outputs.pwm[i] : 0); }
  json += "],\"case1\":["; json += String(s.case1P1) + ',' + String(s.case1P2) + ",0]";
  json += ",\"case2\":["; json += String(s.flushP1) + ',' + String(s.flushP2) + ',' + String(s.flushP3) + ']';
  json += ",\"manual\":["; json += String(manual.pwm[0]) + ',' + String(manual.pwm[1]) + ',' + String(manual.pwm[2]) + ']';
  json += ",\"a\":"; json += String(s.a, 7);
  json += ",\"b\":"; json += String(s.b, 5);
  json += ",\"calibrated\":"; json += s.calibrated ? "true" : "false";
  json += ",\"lowFlowLpm\":"; json += String(s.lowFlowLpm, 6);
  json += ",\"lowFlowSeconds\":"; json += String(s.lowFlowSeconds);
  json += ",\"seconds\":"; json += String(s.case1Seconds);
  json += ",\"volume\":"; json += String(s.flushLiters, 3);
  json += ",\"rate\":"; json += String(s.pump3Lpm, 3);
  json += ",\"reserve\":"; json += String(s.reserveLiters, 3);
  json += ",\"sumpLow\":"; json += s.sumpActiveLow ? "true" : "false";
  json += ",\"flushLow\":"; json += s.flushEmptyActiveLow ? "true" : "false";
  json += '}';
  xSemaphoreGive(controlMutex);
  server.sendHeader("Cache-Control", "no-store"); server.send(200, "application/json", json);
}

// Read completed hardware-switch trials; no network request starts/stops timing.
void handleMeasurement() {
  PulseTrial records[TRIAL_CAPACITY];
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  const uint32_t boot = bootCount, total = recordedTrialCount;
  const uint32_t count = total < TRIAL_CAPACITY ? total : TRIAL_CAPACITY;
  for (uint32_t i = 0; i < count; ++i) records[i] = recordedTrials[(total - count + i) % TRIAL_CAPACITY];
  xSemaphoreGive(controlMutex);
  String json = "{\"bootCount\":" + String(boot) + ",\"discarded\":" + String(total - count) + ",\"trials\":[";
  for (uint32_t i = 0; i < count; ++i) {
    if (i) json += ',';
    json += "{\"trialId\":" + String(records[i].id);
    json += ",\"pulses\":" + String(records[i].pulses);
    json += ",\"milliseconds\":" + String(records[i].milliseconds);
    json += ",\"hz\":" + String(records[i].milliseconds ? records[i].pulses * 1000.0 / records[i].milliseconds : 0, 6) + "}";
  }
  json += "]}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", json);
}

void handleCase1Results() {
  const uint32_t requestedRun = server.arg("run").toInt();
  uint32_t after = server.arg("after").toInt();
  Case1Sample samples[120];
  xSemaphoreTake(controlMutex, portMAX_DELAY);
  const uint32_t run = case1RunId, total = case1SampleCount, boot = bootCount;
  const uint32_t oldest = total > CASE1_CAPACITY ? total - CASE1_CAPACITY : 0;
  if (requestedRun != run || after > total) after = 0;
  if (after < oldest) after = oldest;
  const uint32_t count = total - after > 120 ? 120 : total - after;
  for (uint32_t i = 0; i < count; ++i) samples[i] = case1Samples[(after + i) % CASE1_CAPACITY];
  const bool active = case1Recording;
  const uint32_t elapsed = case1ElapsedMs;
  const double liters = case1Liters;
  xSemaphoreGive(controlMutex);
  String json; json.reserve(16000);
  json = "{\"bootCount\":" + String(boot) + ",\"runId\":" + String(run) + ",\"active\":" + (active ? "true" : "false");
  json += ",\"elapsedMs\":" + String(elapsed) + ",\"liters\":" + String(liters, 6);
  json += ",\"discarded\":" + String(oldest) + ",\"totalSamples\":" + String(total) + ",\"samples\":[";
  for (uint32_t i = 0; i < count; ++i) {
    if (i) json += ',';
    json += "{\"seq\":" + String(after + i + 1) + ",\"elapsedMs\":" + String(samples[i].elapsedMs);
    json += ",\"lpm\":" + String(samples[i].lpm, 6) + ",\"liters\":" + String(samples[i].liters, 6) + "}";
  }
  json += "]}";
  server.sendHeader("Cache-Control", "no-store"); server.send(200, "application/json", json);
}

void setup() {
  Serial.setTxBufferSize(1024);
  Serial.begin(115200);
  for (int i = 0; i < 3; ++i) {
    pinMode(PINS[i].enableL, OUTPUT); pinMode(PINS[i].enableR, OUTPUT);
    digitalWrite(PINS[i].enableL, LOW); digitalWrite(PINS[i].enableR, LOW);
    pinMode(PINS[i].pwm, OUTPUT); digitalWrite(PINS[i].pwm, LOW);
    if (PINS[i].reverse >= 0) { pinMode(PINS[i].reverse, OUTPUT); digitalWrite(PINS[i].reverse, LOW); }
  }
  pinMode(VALVE_PIN, OUTPUT); digitalWrite(VALVE_PIN, VALVE_ACTIVE_HIGH ? LOW : HIGH);
  for (int i = 0; i < 3; ++i) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
    if (!ledcAttach(PINS[i].pwm, PWM_FREQUENCY, PWM_RESOLUTION)) pwmReady = false;
#else
    if (ledcSetup(i, PWM_FREQUENCY, PWM_RESOLUTION) == 0) pwmReady = false;
    ledcAttachPin(PINS[i].pwm, i);
#endif
    writePwm(i, 0);
  }
  sump.begin(); flushFloat.begin(); button.begin();
  loadSettings(); pinMode(FLOW_PIN, INPUT_PULLUP); // Only after 3.3 V signal level conversion.
  bootResetReason = esp_reset_reason();
  bootCount = preferences.getUInt("boots", 0) + 1;
  preferences.putUInt("boots", bootCount);
  Serial.printf("\nBOOT %lu: reset=%s (%d)\n", (unsigned long)bootCount,
                resetReasonName(bootResetReason), int(bootResetReason));
  attachInterrupt(digitalPinToInterrupt(FLOW_PIN), flowInterrupt, FALLING);
  resetTotals(millis());
  controlMutex = xSemaphoreCreateMutex();
  if (!controlMutex) { Serial.println("Control mutex allocation failed; stopped."); while (true) delay(1000); }
  if (!pwmReady) controller.fault(millis(), "PWM initialization failed.");

  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
  if (!WiFi.softAP(WIFI_NAME, WIFI_PASSWORD)) controller.fault(millis(), "Wi-Fi access point startup failed.");
  server.on("/", HTTP_GET, []() { server.send_P(200, "text/html", DASHBOARD); });
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/case1", HTTP_GET, handleCase1Results);
  server.on("/api/measurement", HTTP_GET, handleMeasurement);
  server.on("/api/action", HTTP_POST, handleAction);
  server.on("/api/pwm", HTTP_POST, handlePwm);
  server.on("/api/valve", HTTP_POST, handleValve);
  server.on("/api/failsafe", HTTP_POST, handleFailsafeConfig);
  server.on("/api/config", HTTP_POST, handleConfig);
  server.on("/api/manual", HTTP_POST, handleManualConfig);
  server.on("/api/case2", HTTP_POST, handleCase2Config);
  server.onNotFound([]() { server.send(404, "text/plain", "Not found"); }); server.begin();
  if (xTaskCreatePinnedToCore(controlTask, "Flow control", 4096, nullptr, 2, nullptr, 1) != pdPASS) {
    controller.fault(millis(), "Control task startup failed."); applyOutputs();
    Serial.println("Control task startup failed; stopped."); while (true) delay(1000);
  }
  Serial.printf("\nWi-Fi: %s\nPassword: %s\nDashboard: http://%s\n", WIFI_NAME, WIFI_PASSWORD,
                WiFi.softAPIP().toString().c_str());
}
void logDiagnostics() {
  static uint32_t lastLog = 0;
  static Mode previousMode = Mode::Off;
  static const char* previousMessage = nullptr;
  // Copy a snapshot, then log outside the mutex so Serial cannot block control.
  if (xSemaphoreTake(controlMutex, pdMS_TO_TICKS(2)) != pdTRUE) return;
  const uint32_t now = millis();
  const Mode mode = controller.mode;
  const char* message = controller.message;
  const bool changed = mode != previousMode || message != previousMessage;
  char line[300];
  if (changed || uint32_t(now - lastLog) >= 5000) {
    snprintf(line, sizeof(line), "up=%lus mode=%s button=%d run=%d pulses=%lu Q=%.3f heap=%lu reason=%s\n",
      (unsigned long)(now / 1000), controller.name(), switchClosed(), runButton.running,
      (unsigned long)readPulses(), double(flowLpm), (unsigned long)ESP.getFreeHeap(), message);
  } else line[0] = 0;
  xSemaphoreGive(controlMutex);
  if (line[0]) {
    const size_t length = strlen(line);
    if (Serial.availableForWrite() >= int(length)) {
      Serial.write(reinterpret_cast<const uint8_t*>(line), length);
      lastLog = now; previousMode = mode; previousMessage = message;
    }
  }
}
void loop() { server.handleClient(); logDiagnostics(); delay(1); }
