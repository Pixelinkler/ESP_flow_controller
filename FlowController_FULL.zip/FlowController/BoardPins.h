#pragma once
// class for each pump driver 4 main pins
struct PumpPins { int pwm, reverse, enableL, enableR; };
constexpr PumpPins PINS[3] = {
  {32, 33, 13, 26},
  {18, -1, 16, 17}, // R_PWM2=GPIO19 on drawing, but its PCB trace is missing.
  {23, 25, 21, 22}
};
// All the pin in the PCB for float switch, sump,solinoid valve
constexpr int FLOW_PIN = 14;
constexpr int SUMP_FLOAT_PIN = 35; 
constexpr int FLUSH_FLOAT_PIN = -1; // Optional flush low-level sensor is not fitted.
constexpr int BUTTON_PIN = 34;     
constexpr int VALVE_PIN = 27;

//active state for solinoid and switch to run the cases 
constexpr bool VALVE_ACTIVE_HIGH = true;
constexpr bool RUN_SWITCH_ACTIVE_LOW = true; 

// motor drive pwm freq according to data sheet
constexpr uint32_t PWM_FREQUENCY = 15000;
constexpr uint8_t PWM_RESOLUTION = 10;// step change for every 1% or resolution

// please change mat karna dashboard password
constexpr char WIFI_NAME[] = "Please_Stage3";
constexpr char WIFI_PASSWORD[] = "Jaijairam";

