#include "../ControlLogic.h"
#include "../FlowReading.h"
#include <assert.h>
#include <stdio.h>
#include <limits>

void assertOff(const ProcessController& c) {
  assert(!c.outputs.valve);
  for (int duty : c.outputs.pwm) assert(duty == 0);
}
int main() {
  Inputs in; in.runEnabled = true; in.flowLpm = 3;
  ProcessController c;
  assert(validSettings(c.settings));
  assert(c.startCase1(0, in, false, false));
  assert(c.outputs.pwm[0] == 50 && c.outputs.pwm[1] == 100 && c.outputs.pwm[2] == 0);
  assert(c.outputs.valve);
  in.sumpHigh = true; in.pulses = 10; c.tick(1000, in);
  assert(c.outputs.pwm[0] == 0 && c.outputs.pwm[1] == 100 && !c.outputs.valve);
  in.sumpHigh = false; in.pulses++; c.tick(2000, in);
  assert(c.outputs.pwm[0] == 50 && c.outputs.valve);
  c.stop(2000); assertOff(c);

  // Case 2 requires water confirmation, not a pre-measured Pump 3 rate.
  assert(!c.startCase2(2000, in, false));
  c.settings.pump3Lpm = 3;
  assert(!c.startCase2(2000, in, false));
  assert(c.startCase2(2000, in, true)); assertOff(c);
  c.tick(2499, in); assert(c.mode == Mode::Transition); assertOff(c);
  c.tick(2500, in); assert(c.mode == Mode::Case2);
  assert(!c.outputs.valve);
  assert(c.outputs.pwm[0] == 0 && c.outputs.pwm[1] == 100 && c.outputs.pwm[2] == 100);
  for (uint32_t t = 3500; t < 83500; t += 1000) { in.pulses++; c.tick(t, in); }
  in.pulses++; in.returnedLiters = c.settings.flushLiters; c.tick(83500, in);
  assert(c.mode == Mode::Complete); assertOff(c);

  // FT-01 volume, not elapsed time or estimated Pump 3 flow, ends Case 2.
  ProcessController measured; Inputs measuredInput; measuredInput.runEnabled = true; measuredInput.flowLpm = 3;
  measured.settings.pump3Lpm = 0; measured.settings.flushLiters = 1;
  measured.settings.flushP2 = measured.settings.flushP3 = 65;
  measuredInput.returnedLiters = 12; // Prior Case 1 circulation is excluded.
  assert(measured.startCase2(0, measuredInput, true));
  measured.tick(500, measuredInput);
  measuredInput.returnedLiters = 12.4; measuredInput.pulses = 100;
  measured.tick(10500, measuredInput);
  assert(measured.mode == Mode::Case2 && fabs(measured.flushUsedLiters - 0.4) < 1e-9);
  assert(measured.outputs.pwm[0] == 0 && !measured.outputs.valve);
  assert(measured.outputs.pwm[1] == 65 && measured.outputs.pwm[2] == 65);
  measuredInput.returnedLiters = 12.99; measuredInput.pulses = 200;
  measured.tick(20000, measuredInput); assert(measured.mode == Mode::Case2);
  measuredInput.returnedLiters = 13.01; measuredInput.pulses = 210;
  measured.tick(20500, measuredInput); assert(measured.mode == Mode::Complete); assertOff(measured);

  // Direct low-level sensor works independently of a timed estimate.
  c.stop(90000); c.settings.pump3Lpm = 0; in.flushSensorPresent = true;
  in.flushEmpty = true; assert(!c.startCase2(90000, in, true));
  in.flushEmpty = false; assert(c.startCase2(90000, in, true));
  c.tick(90500, in); assert(c.mode == Mode::Case2);
  in.flushEmpty = true; c.tick(90510, in);
  assert(c.mode == Mode::Complete); assertOff(c);

  // One-go sequence closes source with pumps stopped before flushing.
  c.stop(100000); in.flushEmpty = false; c.settings.case1Seconds = 1;
  assert(c.startCase1(100000, in, true, true));
  in.pulses++; c.tick(101000, in); assert(c.mode == Mode::Transition); assertOff(c);
  c.tick(101500, in); assert(c.mode == Mode::Case2);
  assert(c.outputs.pwm[0] == 0 && !c.outputs.valve);
  in.sumpHigh = true; c.tick(101510, in); assert(c.mode == Mode::Fault); assertOff(c);

  // Return pulse watchdog and startup grace remain active.
  c.stop(110000); in.sumpHigh = false; in.flowLpm = 0;
  assert(c.startCase1(110000, in, false, false));
  c.tick(117999, in); assert(c.mode == Mode::Case1);
  c.tick(118000, in); assert(c.mode == Mode::Fault); assertOff(c);
  c.stop(120000); assert(c.startManual(120000, in));
  assert(!c.setManualPwm(120000, 0, 50, in));
  assert(c.setManualValve(120000, true, in));
  assert(c.setManualPwm(120000, 0, 50, in));
  assert(!c.setManualValve(120000, false, in));
  assert(c.setManualPwm(120000, 2, 100, in));
  c.tick(135000, in); assert(c.mode == Mode::Manual); assert(c.outputs.pwm[0] == 50);

  // Manual must keep running across millis rollover until the physical switch opens.
  c.stop(UINT32_MAX - 1000); assert(c.startManual(UINT32_MAX - 1000, in));
  c.tick(14000, in); assert(c.mode == Mode::Manual);
  in.runEnabled = false; c.tick(14001, in); assertOff(c); in.runEnabled = true;
  Settings bad; bad.a = std::numeric_limits<float>::quiet_NaN(); assert(!validSettings(bad));
  // A held switch at boot or at website selection requires a release before starting.
  RunSwitch run;
  assert(!run.update(true)); assert(!run.update(true));
  assert(!run.update(false)); assert(run.update(true)); assert(!run.update(true));
  run.requireRelease(); assert(!run.update(true));
  assert(!run.update(false)); assert(run.update(true));

  // Every active mode must stop all outputs when its run latch is cleared.
  for (int choice = 0; choice < 4; ++choice) {
    ProcessController gated; Inputs enabled; enabled.runEnabled = true;
    gated.settings.pump3Lpm = 3;
    gated.settings.manualP1 = 40; gated.settings.manualP2 = 80; gated.settings.manualValve = true;
    if (choice == 0) assert(gated.startCase1(0, enabled, false, false));
    if (choice == 1) { assert(gated.startCase2(0, enabled, true)); gated.tick(500, enabled); }
    if (choice == 2) assert(gated.startCase1(0, enabled, true, true));
    if (choice == 3) assert(gated.startManual(0, enabled));
    assert(gated.outputs.pwm[1] > 0);
    if (choice == 1) assert(gated.outputs.pwm[0] == 0 && !gated.outputs.valve);
    enabled.runEnabled = false; gated.tick(501, enabled);
    assert(gated.mode == Mode::Off); assertOff(gated);
    assert(!gated.startCase1(502, enabled, false, false));
    assert(!gated.startCase2(502, enabled, true));
    assert(!gated.startManual(502, enabled));
    // Holding / re-enabling never automatically restarts without a start command.
    enabled.runEnabled = true; gated.tick(503, enabled); assertOff(gated);
  }
  // Clearing the run latch during isolation prevents the flush from starting.
  c.stop(0); in.runEnabled = true; in.sumpHigh = false;
  assert(c.startCase2(0, in, true)); in.runEnabled = false;
  c.tick(250, in); in.runEnabled = true; c.tick(1000, in); assertOff(c);

  // Manual solenoid-only test and all-three-motor flushing configuration.
  ProcessController manual; Inputs mi; mi.runEnabled = true;
  manual.settings.manualValve = true;
  assert(manual.startManual(0, mi)); assert(manual.outputs.valve);
  assert(manual.setManualValve(1, false, mi)); assert(!manual.outputs.valve);
  manual.stop(2); manual.settings.manualP3 = 100;
  assert(manual.startManual(3, mi, false)); // No rate or water confirmation needed.
  manual.stop(4);
  assert(manual.startManual(4, mi, false)); assert(manual.outputs.pwm[2] == 100);
  manual.tick(81004, mi);
  assert(manual.mode == Mode::Manual && manual.outputs.pwm[2] == 100); // No estimated budget.
  manual.stop(82000); mi.flushSensorPresent = true; mi.flushEmpty = false;
  manual.settings.pump3Lpm = 0;
  assert(manual.startManual(82000, mi, true));
  mi.flushEmpty = true; manual.tick(82001, mi); assertOff(manual);

  ProcessController pureManual; Inputs pureInput; pureInput.runEnabled = true;
  pureManual.settings.manualP3 = 53; // Independent of Case 2 shared PWM = 100.
  assert(pureManual.startManual(0, pureInput));
  pureInput.returnedLiters = 100;
  pureManual.tick(900000, pureInput); // Beyond Case 2 duration/water limits.
  assert(pureManual.mode == Mode::Manual && pureManual.outputs.pwm[2] == 53);
  assert(pureManual.setManualPwm(900001, 2, 62, pureInput));
  assert(pureManual.outputs.pwm[2] == 62 && pureManual.settings.flushP3 == 100);
  pureInput.sumpHigh = true; pureManual.tick(900010, pureInput);
  assert(pureManual.mode == Mode::Fault); assertOff(pureManual);

  // ESP32 stores trial boundaries/results; release retries never extend a result.
  PulseTrial trial;
  assert(!trial.stop({100, 10}));
  assert(trial.start({1000, 100}));
  assert(!trial.start({2000, 200})); // Duplicate press preserves the original start.
  assert(trial.stop({3000, 688}));
  assert(trial.pulses == 588 && trial.milliseconds == 2000);
  assert(trial.stop({5000, 900}));
  assert(trial.pulses == 588 && trial.milliseconds == 2000);
  assert(trial.start({UINT32_MAX - 499, UINT32_MAX - 9}));
  assert(trial.id == 2 && trial.pulses == 0 && !trial.complete);
  assert(trial.stop({500, 10}));
  assert(trial.pulses == 20 && trial.milliseconds == 1000);

  // The physical button toggles only on a fresh press. Release never stops.
  RunButton toggle;
  assert(!toggle.update(true, true) && !toggle.running); // Held at boot.
  assert(!toggle.update(false, true));
  assert(toggle.update(true, true) && toggle.running);
  assert(!toggle.update(true, true) && toggle.running); // Held press.
  assert(!toggle.update(false, true) && toggle.running); // Release keeps running.
  assert(toggle.update(true, true) && !toggle.running);
  assert(!toggle.update(true, true) && !toggle.running);
  toggle.update(false, false);
  assert(!toggle.update(true, false) && !toggle.running); // No selected/armed mode.
  toggle.requireRelease();
  assert(!toggle.update(true, true));
  toggle.update(false, true); assert(toggle.update(true, true));
  toggle.stop(); assert(!toggle.running);
  assert(!toggle.update(true, true)); // Fault/STOP cannot restart a held button.

  // All modes keep outputs after button release and stop on the next press.
  for (int choice = 0; choice < 4; ++choice) {
    RunButton buttonToggle; ProcessController process; Inputs input;
    process.settings.pump3Lpm = 3;
    process.settings.manualP1 = 50; process.settings.manualP2 = 100;
    process.settings.manualValve = true;
    buttonToggle.update(false, true); assert(buttonToggle.update(true, true));
    input.runEnabled = buttonToggle.running;
    if (choice == 0) assert(process.startCase1(0, input, false, false));
    if (choice == 1) { assert(process.startCase2(0, input, true)); process.tick(500, input); }
    if (choice == 2) assert(process.startCase1(0, input, true, true));
    if (choice == 3) assert(process.startManual(0, input));
    assert(!buttonToggle.update(false, true)); // Releasing physical button.
    input.runEnabled = buttonToggle.running; input.pulses = 294;
    process.tick(1000, input); assert(process.outputs.pwm[1] > 0);
    if (choice == 1) assert(process.outputs.pwm[0] == 0 && !process.outputs.valve);
    assert(buttonToggle.update(true, true)); input.runEnabled = buttonToggle.running;
    process.tick(2000, input); assert(process.mode == Mode::Off); assertOff(process);
  }

  // YF-S401 nominal 294 Hz = 3 L/min. No pulses must never integrate an offset.
  const FlowReading flow = calculateFlow(294, 1000, 1.0f / 98.0f, 0);
  assert(fabsf(flow.hz - 294) < 0.001f && fabsf(flow.lpm - 3) < 0.001f);
  assert(fabs(flow.liters - 0.05) < 0.000001);
  const FlowReading slow = calculateFlow(588, 2000, 1.0f / 98.0f, 0);
  assert(fabsf(slow.lpm - 3) < 0.001f && fabs(slow.liters - 0.1) < 0.000001);
  assert(calculateFlow(0, 1000, 1.0f / 98.0f, 1).liters == 0);
  assert(calculateFlow(5, 0, 1.0f / 98.0f, 0).liters == 0);
  // Supplied chart plots frequency against flow; invert its fitted line.
  const Settings calibratedSettings;
  assert(calibratedSettings.calibrated);
  const FlowReading chart = calculateFlow(1040, 10000, calibratedSettings.a, calibratedSettings.b);
  assert(fabsf(chart.lpm - (104.0f + 1.54f) / 104.0f) < 0.00001f);
  assert(fabs(chart.liters - double(chart.lpm) / 6.0) < 0.000001);
  assert(calculateFlow(0, 1000, calibratedSettings.a, calibratedSettings.b).liters == 0);
  // Browser-independent Case 1 and Manual run for 15 minutes with valid flow.
  for (int choice = 0; choice < 2; ++choice) {
    ProcessController continuous; Inputs ci; ci.runEnabled = true; ci.flowLpm = 3;
    continuous.settings.manualP1 = 50; continuous.settings.manualP2 = 100;
    continuous.settings.manualValve = true;
    if (choice == 0) assert(continuous.startCase1(0, ci, false, false));
    else assert(continuous.startManual(0, ci));
    for (uint32_t t = 1000; t <= 900000; t += 1000) {
      ci.pulses += 294; continuous.tick(t, ci);
      assert(continuous.mode == (choice == 0 ? Mode::Case1 : Mode::Manual));
      assert(continuous.outputs.pwm[1] == 100);
    }
    ci.runEnabled = false; continuous.tick(900010, ci); assertOff(continuous);
  }
  ProcessController faulted; Inputs fi; fi.runEnabled = true;
  assert(faulted.startCase1(0, fi, false, false)); faulted.tick(8000, fi);
  assert(faulted.mode == Mode::Fault);
  const char* retained = faulted.lastFault;
  fi.runEnabled = false; faulted.tick(8010, fi); assert(faulted.mode == Mode::Fault);
  faulted.stop(8020); assert(faulted.lastFault == retained); assertOff(faulted);
  // Configurable continuous low-flow duration, recovery and equality boundary.
  ProcessController low; Inputs li; li.runEnabled = true; li.flowLpm = 3;
  low.settings.lowFlowLpm = 2; low.settings.lowFlowSeconds = 10;
  assert(low.startCase1(0, li, false, false));
  li.flowLpm = 1; li.pulses = 100; low.tick(9000, li);
  li.pulses += 100; low.tick(18999, li); assert(low.mode == Mode::Case1);
  li.flowLpm = 2; low.tick(19000, li); // Equal to threshold is healthy.
  li.flowLpm = 1; low.tick(20000, li);
  low.tick(29999, li); assert(low.mode == Mode::Case1);
  low.tick(30000, li); assert(low.mode == Mode::Fault); assertOff(low);
  // Restart clears the timer; no pulses and startup grace use configured delay.
  low.stop(31000); li.flowLpm = 0;
  assert(low.startCase1(31000, li, false, false));
  low.tick(40999, li); assert(low.mode == Mode::Case1);
  low.tick(41000, li); assert(low.mode == Mode::Fault); assertOff(low);
  // Monitor only Motor 2, and restart the timer after Motor 2 stops.
  low.stop(42000); low.settings.manualP2 = 0;
  assert(low.startManual(42000, li));
  low.tick(60000, li); assert(low.mode == Mode::Manual);
  assert(low.setManualPwm(60000, 1, 50, li));
  low.tick(69999, li); assert(low.mode == Mode::Manual);
  low.tick(70000, li); assert(low.mode == Mode::Fault); assertOff(low);
  // Low-flow timing remains correct across millis rollover.
  low.stop(UINT32_MAX - 4999);
  assert(low.startCase1(UINT32_MAX - 4999, li, false, false));
  low.tick(4999, li); assert(low.mode == Mode::Case1);
  low.tick(5000, li); assert(low.mode == Mode::Fault); assertOff(low);
  // Case 2 uses the same failsafe despite pulses and partial returned volume.
  ProcessController flushLow; Inputs fl; fl.runEnabled = true; fl.flowLpm = 0.5f;
  flushLow.settings.lowFlowLpm = 1; flushLow.settings.lowFlowSeconds = 2;
  assert(flushLow.startCase2(0, fl, true)); flushLow.tick(500, fl);
  fl.pulses = 100; fl.returnedLiters = 0.1; flushLow.tick(8499, fl);
  assert(flushLow.mode == Mode::Case2);
  flushLow.tick(8500, fl); assert(flushLow.mode == Mode::Fault); assertOff(flushLow);
  Settings limits;
  limits.lowFlowLpm = 0; assert(!validSettings(limits));
  limits.lowFlowLpm = std::numeric_limits<float>::quiet_NaN(); assert(!validSettings(limits));
  limits.lowFlowLpm = 20; limits.lowFlowSeconds = 3600; assert(validSettings(limits));
  limits.lowFlowSeconds = 0; assert(!validSettings(limits));
  limits.lowFlowSeconds = 3601; assert(!validSettings(limits));
  puts("PASS: sump protection, flush gating, timed/sensor shutdown, automatic sequence, configurable low-flow failsafe, button toggle, browser-independent operation, retained faults, millis rollover.");
}
