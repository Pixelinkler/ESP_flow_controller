#pragma once
#include <stdint.h>
#include <math.h>

struct PulseSnapshot { uint32_t ms, pulses; };
struct Case1Sample { uint32_t elapsedMs; float lpm; double liters; };
struct PulseTrial {
  bool active = false, complete = false;
  uint32_t id = 0, pulses = 0, milliseconds = 0;
  PulseSnapshot started = {0, 0};
  bool start(PulseSnapshot snapshot) {
    if (active) return false;
    started = snapshot; active = true; complete = false;
    ++id; pulses = milliseconds = 0; return true;
  }
  bool stop(PulseSnapshot snapshot) {
    if (!active) return complete; // Repeated release returns the same frozen result.
    pulses = snapshot.pulses - started.pulses;
    milliseconds = snapshot.ms - started.ms;
    active = false; complete = true; return true;
  }
};
struct FlowReading { float hz = 0, lpm = 0; double liters = 0; };
inline FlowReading calculateFlow(uint32_t pulses, uint32_t milliseconds, float a, float b) {
  FlowReading reading;
  if (!milliseconds || !pulses) return reading;
  reading.hz = pulses * 1000.0f / milliseconds;
  reading.lpm = fmaxf(0, a * reading.hz + b);
  reading.liters = double(reading.lpm) * milliseconds / 60000.0;
  return reading;
}
