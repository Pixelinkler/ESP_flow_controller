# ESP32 Flow Controller

Open `FlowController.ino` in Arduino IDE with all headers in the same folder.
Select ESP32 Dev Module / the supplied NodeMCU-32S. Alternatively run `pio run`
using PlatformIO. Uploading the new firmware is required to change the dashboard.

Connect to Wi-Fi **Lam-Stage2**, password **LamFlow2026**, and open
**http://192.168.4.1**. No internet or router is required.

## Select a mode, then toggle with the physical button

1. While stopped, configure motor PWM and flush settings.
2. Choose Case 1, Case 2, Case 1 → Case 2, or Manual and click **Select mode**.
3. Press the physical button between **SW / GPIO34 and GND** once to start.
4. Release it: the process continues running.
5. Press it again to stop all motors and de-energize the source solenoid.

A press must remain stable for 50 ms to be accepted. Holding the button never
repeats the action; release it between presses. A button held at boot cannot
start equipment until released and pressed again. Selecting a mode stops any
existing run and requires a fresh press. The button is a software start/stop
control, not a hardware emergency-stop circuit.

A normal button stop retains the selected mode for the next press. Dashboard
STOP, fault, completion or rejected start requires selecting a mode again.
Selection and the run latch are not retained after reboot. Saved settings are
retained. Processes continue independently of the browser and button release;
flow, level and flush-limit protections remain active.

## Four operating modes

**Case 1:** Default Motor 1 = 50%, Motor 2 = 100%, Motor 3 = OFF. At high sump
level, Motor 1 stops and the source solenoid closes. Motor 2 continues draining.
When the sump float clears, Motor 1 and source supply resume. Standalone Case 1
has no duration limit; the transition delay applies only to the combined mode.

**Case 2:** Stop all pumps, close the source valve, wait 500 ms, then run
Motors 2 and 3 at one shared flush PWM (default 100%). Motor 1 stays OFF
(0%) and the solenoid stays closed throughout Case 2. Older saved Motor 1 flush
PWM settings are forced to zero on upgrade. High sump, no-return-flow faults, flush
completion, the second button press, or the 10-minute maximum stop the run.

**Case 1 → Case 2:** Run Case 1 for the configured delay (default 60 seconds),
then automatically enter the Case 2 isolation / flushing sequence. Configure
Case 1 motor settings by choosing Case 1; the combined mode's motor form edits
the Case 2 settings. The run latch remains active through both phases.

**Manual:** Set each motor independently (0–100%) and solenoid ON/OFF while
stopped, save, select Manual, then press the physical button once. Press again
to stop. Motor 1 requires the solenoid ON. A solenoid-only check is possible
with all motors zero. Manual has no starting-water entry, measured Motor 3 rate,
flush-ready requirement, automatic volume budget or duration limit. Its Motor 3
PWM is independent of Case 2 and does not change the Case 2 settings. Sump HIGH
still inhibits Motor 1/source valve and stops a run using Motor 3; an installed
flush low-level float and Motor 2's low-flow failsafe remain active.

## Case 2 tab and flush prerequisites

The dashboard has Case 1, Case 2 and Manual settings tabs. The Case 2 tab contains
actual flush-tank starting litres (up to 4.2 L) and one PWM (1–100%) shared by
Motors 2 and 3. Motor 1 stays at 0% and the source solenoid stays closed. Select
Case 2 for standalone flushing. Select Case 1 → Case 2 for a combined run; its
transition delay appears only in the Case 2 tab. The Manual tab has no
combined-mode delay. Mode selection still requires the Select mode action and
physical start button.

Fill the flush tank, open its manual ball valve and confirm the checkbox.
Case 2 does not require a measured Motor 3 consumption rate. On entering the
flush phase after isolation, the controller captures the monotonic calibrated
FT-01 volume baseline. It stops Motors 2/3 when volume measured during that
phase reaches the starting water entered in the tab. Prior Case 1 flow and
Reset flow totals do not affect this baseline. During Case 2, flow samples are
normally updated every 100 ms. The displayed remaining seconds use remaining
litres × 60 / current measured L/min and are undefined at zero flow; shutdown
is driven by measured volume, not that countdown.

FT-01 is on the sump return, not the flush-tank outlet. Returned volume estimates
flush-water depletion only if sump inventory changes and other fluid sources
are negligible. It cannot directly detect tank level or loss of prime. An
optional low-level float also stops flushing. Sump HIGH, low-return-flow
protection and the ten-minute maximum remain active.

Manual runs use independent PWM/solenoid commands and no water-budget settings.
No flush-level sensor is configured by default (`FLUSH_FLOAT_PIN = -1`). Add a
low-level float between GPIO4 and GND and set that pin to 4 for direct level
shutdown. GPIO17/18 belong to Motor 2. The dashboard's **Low-flow failsafe** panel controls the minimum FT-01 return
flow (0.001–20 L/min, default 0.1) and continuous low-flow shutoff delay
(1–3600 whole seconds, default 5). Save while stopped with the physical button
released, then select a mode again. Both values persist across restarts; older
saved motor/flush settings are migrated. While Motor 2 runs in any mode, flow
below the threshold for the delay stops all motors and closes the solenoid.
Recovery to or above the threshold resets the timer. An 8-second startup grace
runs concurrently with the delay, so shutdown cannot occur before 8 seconds
from Motor 2 starting. The failsafe uses the same calibrated L/min reading as
the dashboard, including zero when no pulses arrive.

## YF-S401 readings and troubleshooting

The supplied `../flow_calib.png` plots frequency against flow with the fitted
line `f = 104 Q - 1.54` and displayed R² = 0.999. Firmware uses its inverse:
`Q (L/min) = (f + 1.54) / 104`, a = 1/104 and b = 1.54/104. These coefficients
replace saved older calibration at boot and cannot be edited from the dashboard.
Zero pulses produce zero flow and zero integrated volume despite the fitted
offset. Settings use version 2 storage; motor and water settings are preserved.

GPIO14 counts FALLING edges, one per sensor pulse, with INPUT_PULLUP. The
pull-up helps an open-collector / level-converted signal; it does not convert
5 V to 3.3 V. Supply the sensor with the specified 5 V, share GND, and feed its
signal to GPIO14 through appropriate level conversion. The supplied PCB flow
connector is pin 1 = FS, pin 2 = +5 V, pin 3 = GND. Match functions rather than
assuming cable colors. The YF-S401 can output a HIGH above 4.5 V at 5 V supply;
never connect that directly to an ESP32 input.

The top dashboard reading shows only L/min for screenshots. The Sensor and
solenoid checks panel shows pulse samples, GPIO levels and controller health.
Reset flow totals clears the overall counters while preserving Case 1 run totals
and Case 2 volume shutdown tracking.
If pulses remain zero with water flowing, inspect sensor power, common ground,
signal level / continuity, correct inlet direction and a free rotor. Calibration
cannot repair absent pulses or a damaged GPIO. Outputs and valve status are
commands, not measured motor speed / valve motion.

## Case 1 results

A successful Case 1 start automatically starts ESP32 recording. The results
panel shows the current return flow in mL/s, elapsed seconds and cumulative
litres returned to the 10 L tank during that Case 1 run. A canvas graph plots
mL/s versus elapsed seconds, with the 3 L/min = 50 mL/s reference. Download Case 1
CSV includes elapsed seconds, flow in mL/s, flow in L/min and total returned
litres. Download graph PNG saves the plotted trend; the main L/min reading is
available for screenshots. Total returned is cumulative throughput, not the
volume currently inside the tank.

The ESP32 retains the latest 1200 samples (normally 20 minutes) of its latest
Case 1 run in RAM, even without a connected browser. Its cumulative total covers
the complete run even if older graph samples expire. The browser retrieves data
in batches and resumes after reconnection. A new Case 1 run resets its graph,
elapsed time and run total. Stop/fault freezes results; in combined mode only
the Case 1 phase is recorded, ending at isolation. Reset flow totals affects
the overall counters, but not the Case 1 run total. Download before starting
another Case 1 run or restarting the ESP32; reboot clears RAM.

The flow calibration/flushing section, general Case 1/Case 2 process log,
valve-position recorder and hydraulic-observations sections have been removed.
Case 2 starting water/shared PWM/combined delay are in its settings tab. Manual
contains only independent motor PWM and solenoid controls. Reserve and float
polarity remain in saved settings and can be changed through the configuration
API if needed.

## Recorded trials

A successful physical-button start captures the ESP32 raw pulse counter and
time. The next press stops the selected process and freezes the trial. Release
does not stop timing or motors. Dashboard STOP, mode selection, fault or
completion also freeze the trial; rejected starts create no trial. Both presses
use 50 ms debounce, with an intervening release. Results are independent of
Wi-Fi and resets of the overall flow totals.

The ESP32 stores its latest 32 completed trials in RAM. The dashboard retrieves
completed results, queues unsaved trials chronologically and allows entering
collected litres before saving. The table/CSV contain pulses N, seconds t,
frequency N/t, collected litres V and actual flow 60V/t, plus hardware trial ID
and boot number. Browser tables clear on reload; download the CSV first.
Reboot clears ESP32 trials. Trial durations must be below the approximately
49-day millis rollover period. Calibration fitting is removed because the
supplied graph now defines the firmware coefficients.

## Solenoid 2W025-08 and D4184

GPIO27 / PCB SV controls the MOSFET input with steady HIGH (ON) and LOW (OFF).
`VALVE_ACTIVE_HIGH = true` matches the normal active-HIGH D4184 module.
The PCB three-pin solenoid interface is pin 1 = SV, pin 2 = +5 V, pin 3 = GND.
The +5 V interface supply is not the 12 V coil / driver load supply.

For the common module labelled DC+/DC-, OUT+/OUT-, PWM/GND:

- GPIO27 / SV → PWM / trigger.
- PCB GND → signal GND and the common supply ground.
- Matching coil power supply → DC+ / DC- (12 V DC only if the coil says 12 V DC).
- Coil wires → OUT+ / OUT-.

Some D4184 modules instead have supply +/-, LOAD and IN/SIG. Connect the coil
between supply + and switched LOAD per that module's documentation. Do not
assume the terminal order. Use suitable flyback protection across a DC coil
(cathode to coil positive, anode to switched negative) unless built in.

The 2W025-08 model exists in several AC/DC coil voltages; read the coil label.
The code assumes a normally closed valve. Software cannot correct a wrong coil
voltage, missing load power, incorrect terminals or failed MOSFET / coil.

To check: configure Manual with all motors zero and solenoid ON, select Manual,
then press the button once. Check GPIO27 rises to about 3.3 V and the voltage across
the coil reaches its rating. Press again: GPIO27 must return LOW and coil power
must switch off. Repeat with solenoid OFF. Dashboard valve status is a command,
not a physical valve-position measurement. Upload only with the switch open.

## GPIO wiring

| Component | Signal | GPIO |
| --- | --- | --- |
| Motor 1 | LPWM / RPWM | 32 / 33 |
| Motor 1 | L_EN / R_EN | 13 / 26 |
| Motor 2 | LPWM / RPWM | 18 / missing PCB trace |
| Motor 2 | L_EN / R_EN | 16 / 17 |
| Motor 3 | LPWM / RPWM | 23 / 25 |
| Motor 3 | L_EN / R_EN | 21 / 22 |
| Flow | FS | 14 |
| Sump float | FSW | 35 |
| Run switch | SW | 34 |
| Solenoid | SV | 27 |

Use GPIO labels, not physical ESP32 socket positions. GPIO34/35 have external
PCB pull-ups. Motor 2's unused RPWM must be held LOW at the BTS7960, not floating.
Check actual pump polarity and inlet/outlet arrows. The hydraulic path is:
process tank → solenoid → tee → Motor 1 → sump → Motor 2 → FT-01 → process tank.
The flush tank feeds the tee through its manual ball valve and Motor 3.

## Validation

```
g++ -std=c++11 -Wall -Wextra -pedantic tests/control_test.cpp -o /tmp/lam-flow-test
/tmp/lam-flow-test
pio run
```

Tests cover all-mode run-latch shutdown, press-to-toggle operation, fresh-press behavior, sump pause /
resume, manual solenoid and Motor 3 controls, flush prerequisites and limits,
low-flow failsafe, 15-minute browser-independent operation, retained fault
messages, millis rollover and YF-S401 calculations.
Hardware operation still requires on-device verification.

References:
- YF-S401: https://wiki.dfrobot.com/sen0216/
- D4184: https://robu.in/wp-content/uploads/2025/01/USER-MANUAL-1.pdf
- Coil variants: https://www.brandopneumatic.com/brass-solenoid-valve/59425067.html

## Unexpected stops / Wi-Fi disconnections

Standalone Case 1 and Manual have no operating-time
limit or browser heartbeat timeout. Pressing the physical button again, a flow fault,
or a level / flush condition still stops equipment. Low-flow protection can
stop either mode after the configured delay (subject to the 8-second startup
grace) if Motor 2 produces no sensor pulses. Fix sensor / hydraulic problems rather than disabling that protection.
A normal controller fault does not disable the Wi-Fi access point.

The Serial Monitor at 115200 prints the boot reset reason, startup errors,
mode/message changes and diagnostic snapshots every five seconds. Logging occurs
outside the control mutex and skips writes when the transmit buffer is full. The last fault is
retained within the same boot, but not across power loss. Boot count is stored
once per boot; reset metadata remains available through the status API.

An incremented boot count / reset uptime means a restart, not just an HTTP
request failure. Brownout / supply voltage drop points to unstable controller
power; crash and watchdog resets require the Serial panic / backtrace output.
A full power interruption can report Power-on rather than Brownout. Keep the
3.3 V / 5 V controller supply stable under pump load, use proper motor supply
wiring, and verify the DC solenoid has flyback protection. Software diagnostics
cannot fix an undersized supply, interference, a bad ground or regulator failure.

After a fault, correct the cause, select the mode again, then release and press
the switch. After a reboot, reconnect to Lam-Stage2 and select a mode again.
Automatic motor restart after a reset is intentionally prevented.
